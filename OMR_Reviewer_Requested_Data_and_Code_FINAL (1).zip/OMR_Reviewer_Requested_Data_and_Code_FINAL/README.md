# OMR reproducibility supplement - Major Concern 6 and path-consistent robust revision

This supplement accompanies manuscript OMRA-D-26-00553R1. It contains executable analyses, public-source registries, input tables, raw outputs, figures, software requirements, and validation records used for the revised manuscript.

Two substantive revisions are reproduced here:

1. **Response-independent disruption requirements (Reviewer 3, Major Concern 6).** Static requirements are now defined as `D_s = gamma_s F0`, with `F0 = 20.3` mb/d and central severity fractions `(0.30, 0.50, 0.80)`. The duration-aware path uses `(0.80, 0.50, 0.40)`. Dated 2026 Hormuz flows are contextual plausibility checks only and do not enter the requirement equations.
2. **Path-consistent dynamic robustness (Reviewer 3, Minor Concern 5).** Capacity deterioration is persistent across the full acute-restricted-recovery path rather than renewed independently in each phase.

Run the scripts from the supplement root. `replication/core_empirical_model.py` also generates the 27-combination severity-band robustness check reported in the manuscript. The active duration-aware implementation is `replication/duration_aware_hormuz_optimization.py`.
