# Replication instructions

From the supplement root, install the pinned dependencies in `replication/requirements.txt` and `replication/core_requirements.txt`, then run:

1. `python replication/core_empirical_model.py`
2. `python replication/temporal_validation_2020_2026.py`
3. `python replication/duration_aware_hormuz_optimization.py`
4. `python replication/validate_path_consistent_robust.py`

The core script reproduces the static deterministic, stochastic, CVaR and robust analyses, the factorial sensitivity analysis, figures, and the 27-combination severity-band robustness check. The temporal-validation script reproduces the pre-2026 operating-envelope and retrospective transfer diagnostics. The duration-aware script reproduces the nominal and path-consistent robust multi-period analyses. The validation script performs the interior-state numerical stress check.

Generated CSV/JSON outputs are written to `outputs/`, figures to `figures/`, and the duration-aware workbook to `data/`.
