# OMR core empirical replication package

Run `python replication/core_empirical_model.py` from the package root. The script rebuilds all CSV outputs and figures.

Evidence rules:
- Public observations are stored in `outputs/public_source_registry.csv`.
- Scenario probabilities, normalised costs, penalties, and budget levels are planning assumptions, not observed facts.
- The lower, central, and upper response profiles are evidence-bounded stress-test profiles.
- No practitioner validation is claimed.
