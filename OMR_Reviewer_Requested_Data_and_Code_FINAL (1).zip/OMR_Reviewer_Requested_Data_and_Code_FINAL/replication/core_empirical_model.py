#!/usr/bin/env python3
from __future__ import annotations
import json, platform, time
from pathlib import Path
from dataclasses import dataclass
import numpy as np
import pandas as pd
import scipy
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs'; FIG = ROOT / 'figures'; REP = ROOT / 'replication'
OUT.mkdir(exist_ok=True); FIG.mkdir(exist_ok=True); REP.mkdir(exist_ok=True)

ACTIONS = ['Emergency stocks','Bypass activation','Demand adaptation']
SCENARIOS = ['Moderate stress','Severe stress','Extreme stress']
K, S = len(ACTIONS), len(SCENARIOS)

# Static planning requirements are defined independently of realised 2026 response.
# Public retained-flow observations are kept only for contextual plausibility checks.
BASELINE = 20.3
SEVERITY_FRACTIONS = np.array([0.30, 0.50, 0.80])
D = BASELINE * SEVERITY_FRACTIONS
RETAINED_CONTEXT = np.array([14.6, 12.0, 3.8])
OBSERVED_REDUCTION_FRACTIONS = 1.0 - RETAINED_CONTEXT / BASELINE

# Response-capacity bands (mb/d-equivalent). These are evidence-bounded
# planning profiles, not causal estimates of a single organisation's capacity.
PROFILES = {
    'Lower-response': np.array([1.25, 2.60, 1.10]),
    'Central-response': np.array([2.50, 4.70, 2.50]),
    'Upper-response': np.array([3.80, 5.50, 5.00]),
}

# Normalised preparedness and activation weights. They are transparent
# planning weights and are varied in sensitivity tests; they are not monetary data.
c_base = np.array([0.80, 1.20, 0.60])
h_base = np.array([0.20, 0.40, 0.15])

PRIORS = {
    'Tail-light': np.array([0.65,0.25,0.10]),
    'Balanced': np.array([0.50,0.30,0.20]),
    'Tail-heavy': np.array([0.30,0.35,0.35]),
    'Uniform': np.array([1/3,1/3,1/3]),
}
penalty_base = np.array([15.0, 25.0, 60.0])

@dataclass
class Eval:
    policy: str
    x: np.ndarray
    y: np.ndarray
    u: np.ndarray
    solver_objective: float
    first_cost: float
    expected_activation: float
    expected_penalty: float
    expected_total: float
    scenario_loss: np.ndarray
    navigability: np.ndarray


def check(res, label):
    if not res.success:
        raise RuntimeError(f'{label}: {res.message}')


def constraints(n, B, C):
    A=[]; b=[]
    row=np.zeros(n); row[:K]=c_base; A.append(row); b.append(B)
    for s in range(S):
        for k in range(K):
            row=np.zeros(n); row[K+s*K+k]=1; row[k]=-1
            A.append(row); b.append(0.0)
    return A,b


def solve_sp(B,p,pen,C,c_mult=1.0,h_mult=1.0):
    global c_base,h_base
    c0=c_base*c_mult; h0=h_base*h_mult
    n=K+S*K+S
    obj=np.zeros(n); obj[:K]=c0
    for s in range(S):
        obj[K+s*K:K+(s+1)*K]=p[s]*h0
        obj[K+S*K+s]=p[s]*pen[s]
    A=[]; b=[]
    row=np.zeros(n); row[:K]=c0; A.append(row); b.append(B)
    for s in range(S):
        for k in range(K):
            row=np.zeros(n); row[K+s*K+k]=1; row[k]=-1; A.append(row); b.append(0.0)
        row=np.zeros(n); row[K+s*K:K+(s+1)*K]=-C; row[K+S*K+s]=-1
        A.append(row); b.append(-D[s])
    bounds=[(0,1)]*K+[(0,None)]*(S*K+S)
    res=linprog(obj,A_ub=np.array(A),b_ub=np.array(b),bounds=bounds,method='highs')
    check(res,'SP')
    return res,c0,h0


def solve_det(B,p,pen,C,c_mult=1.0,h_mult=1.0):
    # Deterministic benchmark: optimise against the most likely partial-disruption
    # scenario only, then evaluate the resulting preparedness portfolio across all
    # observed anchors. This mimics single-scenario planning.
    c0=c_base*c_mult; h0=h_base*h_mult
    sref=0
    n=K+K+1
    obj=np.r_[c0,h0,pen[sref]]
    A=[]; b=[]
    row=np.zeros(n); row[:K]=c0; A.append(row); b.append(B)
    for k in range(K):
        row=np.zeros(n); row[K+k]=1; row[k]=-1; A.append(row); b.append(0.0)
    row=np.zeros(n); row[K:K+K]=-C; row[-1]=-1; A.append(row); b.append(-D[sref])
    bounds=[(0,1)]*K+[(0,None)]*(K+1)
    res=linprog(obj,A_ub=np.array(A),b_ub=np.array(b),bounds=bounds,method='highs')
    check(res,'DET')
    return res,c0,h0

def solve_cvar(B,p,pen,C,alpha=.9,risk_weight=.5,c_mult=1.0,h_mult=1.0):
    c0=c_base*c_mult; h0=h_base*h_mult
    base=K+S*K+S; eta=base; xi0=base+1; n=base+1+S
    obj=np.zeros(n); obj[:K]=c0
    for s in range(S):
        obj[K+s*K:K+(s+1)*K]=p[s]*h0
        obj[K+S*K+s]=p[s]*pen[s]
    obj[eta]=risk_weight; obj[xi0:xi0+S]=risk_weight*p/(1-alpha)
    A=[]; b=[]
    row=np.zeros(n); row[:K]=c0; A.append(row); b.append(B)
    for s in range(S):
        for k in range(K):
            row=np.zeros(n); row[K+s*K+k]=1; row[k]=-1; A.append(row); b.append(0)
        row=np.zeros(n); row[K+s*K:K+(s+1)*K]=-C; row[K+S*K+s]=-1; A.append(row); b.append(-D[s])
        row=np.zeros(n); row[K+s*K:K+(s+1)*K]=h0; row[K+S*K+s]=pen[s]; row[eta]=-1; row[xi0+s]=-1
        A.append(row); b.append(0)
    bounds=[(0,1)]*K+[(0,None)]*(S*K+S)+[(None,None)]+[(0,None)]*S
    res=linprog(obj,A_ub=np.array(A),b_ub=np.array(b),bounds=bounds,method='highs')
    check(res,'CVaR')
    return res,c0,h0


def solve_rob(B,p,pen,C,C_low,omega=1.5,c_mult=1.0,h_mult=1.0):
    c0=c_base*c_mult; h0=h_base*h_mult
    delta=np.maximum(C-C_low,0)
    base=K+S*K+S; theta0=base; r0=base+S; n=r0+S*K
    obj=np.zeros(n); obj[:K]=c0
    for s in range(S):
        obj[K+s*K:K+(s+1)*K]=p[s]*h0
        obj[K+S*K+s]=p[s]*pen[s]
    A=[]; b=[]
    row=np.zeros(n); row[:K]=c0; A.append(row); b.append(B)
    for s in range(S):
        for k in range(K):
            row=np.zeros(n); row[K+s*K+k]=1; row[k]=-1; A.append(row); b.append(0)
        row=np.zeros(n); row[K+s*K:K+(s+1)*K]=-C; row[K+S*K+s]=-1
        row[theta0+s]=omega; row[r0+s*K:r0+(s+1)*K]=1
        A.append(row); b.append(-D[s])
        for k in range(K):
            row=np.zeros(n); row[K+s*K+k]=delta[k]; row[theta0+s]=-1; row[r0+s*K+k]=-1
            A.append(row); b.append(0)
    bounds=[(0,1)]*K+[(0,None)]*(S*K+S+S+S*K)
    res=linprog(obj,A_ub=np.array(A),b_ub=np.array(b),bounds=bounds,method='highs')
    check(res,'ROB')
    return res,c0,h0


def eval_x(policy,x,p,pen,C,c0,h0,solver_obj=np.nan):
    ys=[]; us=[]; losses=[]
    for s in range(S):
        obj=np.r_[h0,pen[s]]
        A=[]; b=[]
        for k in range(K):
            row=np.zeros(K+1); row[k]=1; A.append(row); b.append(x[k])
        row=np.zeros(K+1); row[:K]=-C; row[-1]=-1; A.append(row); b.append(-D[s])
        res=linprog(obj,A_ub=np.array(A),b_ub=np.array(b),bounds=[(0,None)]*(K+1),method='highs')
        check(res,'eval')
        y=res.x[:K]; u=res.x[-1]
        ys.append(y); us.append(u); losses.append(h0@y+pen[s]*u)
    y=np.array(ys); u=np.array(us); loss=np.array(losses)
    first=c0@x; act=p@np.sum(y*h0,axis=1); pe=p@(pen*u)
    return Eval(policy,x,y,u,float(solver_obj),float(first),float(act),float(pe),float(first+act+pe),loss,1-u/D)


def unpack(policy,res,p,pen,C,c0,h0,rob=False,det=False):
    x=res.x[:K]
    return eval_x(policy,x,p,pen,C,c0,h0,res.fun)


def eval_x_robust(policy,x,p,pen,C,C_low,c0,h0,omega=1.5,solver_obj=np.nan):
    delta=np.maximum(C-C_low,0)
    ys=[]; us=[]; losses=[]
    for s in range(S):
        # variables: y[K], u, theta, r[K]
        n=K+1+1+K; uidx=K; tidx=K+1; ridx=K+2
        obj=np.zeros(n); obj[:K]=h0; obj[uidx]=pen[s]
        A=[]; b=[]
        for k in range(K):
            row=np.zeros(n); row[k]=1; A.append(row); b.append(x[k])
        row=np.zeros(n); row[:K]=-C; row[uidx]=-1; row[tidx]=omega; row[ridx:ridx+K]=1
        A.append(row); b.append(-D[s])
        for k in range(K):
            row=np.zeros(n); row[k]=delta[k]; row[tidx]=-1; row[ridx+k]=-1
            A.append(row); b.append(0.0)
        res=linprog(obj,A_ub=np.array(A),b_ub=np.array(b),bounds=[(0,None)]*n,method='highs')
        check(res,'robust fixed-x eval')
        y=res.x[:K]; u=res.x[uidx]
        ys.append(y); us.append(u); losses.append(h0@y+pen[s]*u)
    y=np.array(ys); u=np.array(us); loss=np.array(losses)
    first=c0@x; act=p@np.sum(y*h0,axis=1); pe=p@(pen*u)
    return Eval(policy,x,y,u,float(solver_obj),float(first),float(act),float(pe),float(first+act+pe),loss,1-u/D)


def central_run():
    p=PRIORS['Balanced']; pen=penalty_base.copy(); C=PROFILES['Central-response']; C_low=PROFILES['Lower-response']; B=1.6
    results=[]
    r,c0,h0=solve_det(B,p,pen,C); results.append(unpack('Deterministic',r,p,pen,C,c0,h0,det=True))
    r,c0,h0=solve_sp(B,p,pen,C); results.append(unpack('Stochastic',r,p,pen,C,c0,h0))
    r,c0,h0=solve_cvar(B,p,pen,C,.9,.5); results.append(unpack('CVaR',r,p,pen,C,c0,h0))
    r,c0,h0=solve_rob(B,p,pen,C,C_low,1.5); results.append(unpack('Robust',r,p,pen,C,c0,h0,rob=True))
    guarantees={z.policy:eval_x_robust(z.policy,z.x,p,pen,C,C_low,c0,h0,1.5,z.solver_objective) for z in results}
    rows=[]; scen=[]; mix=[]; guar=[]
    for z in results:
        gz=guarantees[z.policy]
        rows.append({'Policy':z.policy,'First-stage cost':z.first_cost,'Expected activation':z.expected_activation,
                     'Expected penalty':z.expected_penalty,'Nominal expected total':z.expected_total,
                     'Nominal worst residual':z.u.max(),'Nominal worst navigability':z.navigability.min(),
                     'Guaranteed expected total':gz.expected_total,'Guaranteed worst residual':gz.u.max(),
                     'Guaranteed worst navigability':gz.navigability.min(),'Solver objective':z.solver_objective})
        for k,a in enumerate(ACTIONS): mix.append({'Policy':z.policy,'Action':a,'Reservation fraction':z.x[k]})
        for ss,sc in enumerate(SCENARIOS):
            scen.append({'Policy':z.policy,'Scenario':sc,'Planning requirement':D[ss],'Residual':z.u[ss],
                         'Coverage':D[ss]-z.u[ss],'Navigability':z.navigability[ss],'Scenario loss':z.scenario_loss[ss]})
            guar.append({'Policy':z.policy,'Scenario':sc,'Planning requirement':D[ss],'Guaranteed residual':gz.u[ss],
                         'Guaranteed coverage':D[ss]-gz.u[ss],'Guaranteed navigability':gz.navigability[ss],
                         'Guaranteed scenario loss':gz.scenario_loss[ss]})
    pd.DataFrame(rows).to_csv(OUT/'central_policy_summary.csv',index=False)
    pd.DataFrame(mix).to_csv(OUT/'central_reservation_mix.csv',index=False)
    pd.DataFrame(scen).to_csv(OUT/'central_scenario_results.csv',index=False)
    pd.DataFrame(guar).to_csv(OUT/'central_robust_guarantee_results.csv',index=False)
    return results

def factorial():
    rows=[]
    budgets=[1.0,1.3,1.6,1.9,2.2,2.6]
    pen_mults=[0.5,1.0,2.0]
    for prof,C in PROFILES.items():
      for prior,p in PRIORS.items():
       for B in budgets:
        for pm in pen_mults:
         pen=penalty_base*pm; C_low=PROFILES['Lower-response']
         solvers=[('Stochastic',solve_sp(B,p,pen,C)),('CVaR',solve_cvar(B,p,pen,C,.9,.5)),('Robust',solve_rob(B,p,pen,C,C_low,1.5))]
         for name,(r,c0,h0) in solvers:
            z=unpack(name,r,p,pen,C,c0,h0,rob=name=='Robust')
            rows.append({'Profile':prof,'Prior':prior,'Budget':B,'Penalty multiplier':pm,'Policy':name,
                         'Expected total':z.expected_total,'Worst residual':z.u.max(),'Worst navigability':z.navigability.min(),
                         **{f'x_{ACTIONS[k]}':z.x[k] for k in range(K)}})
    df=pd.DataFrame(rows); df.to_csv(OUT/'factorial_policy_results.csv',index=False)
    # Distinctness
    distinct=[]
    for keys,g in df.groupby(['Profile','Prior','Budget','Penalty multiplier']):
        v={r['Policy']:np.array([r[f'x_{a}'] for a in ACTIONS]) for _,r in g.iterrows()}
        distinct.append(dict(zip(['Profile','Prior','Budget','Penalty multiplier'],keys)) | {
            'CVaR differs from stochastic':float(np.max(np.abs(v['CVaR']-v['Stochastic'])))>1e-6,
            'Robust differs from stochastic':float(np.max(np.abs(v['Robust']-v['Stochastic'])))>1e-6,
        })
    pd.DataFrame(distinct).to_csv(OUT/'policy_distinctness.csv',index=False)
    return df


def cvar_grid():
    rows=[]; p=PRIORS['Balanced']; C=PROFILES['Central-response']; pen=penalty_base; B=1.6
    rsp,c0,h0=solve_sp(B,p,pen,C); xsp=rsp.x[:K]
    for alpha in [0.75,0.85,0.90,0.95,0.975]:
      for rw in [0.1,0.25,0.5,1.0,2.0]:
        r,c0,h0=solve_cvar(B,p,pen,C,alpha,rw); z=unpack('CVaR',r,p,pen,C,c0,h0)
        rows.append({'alpha':alpha,'risk_weight':rw,'max_abs_x_difference':float(np.max(np.abs(z.x-xsp))),
                     'Expected total':z.expected_total,'Worst residual':z.u.max(),'Worst navigability':z.navigability.min(),
                     **{f'x_{ACTIONS[k]}':z.x[k] for k in range(K)}})
    pd.DataFrame(rows).to_csv(OUT/'cvar_grid.csv',index=False)


def robust_grid():
    rows=[]; p=PRIORS['Balanced']; C=PROFILES['Central-response']; low=PROFILES['Lower-response']; pen=penalty_base; B=1.6
    rsp,c0,h0=solve_sp(B,p,pen,C); xsp=rsp.x[:K]
    for om in [0,0.5,1.0,1.5,2.0,3.0]:
        r,c0,h0=solve_rob(B,p,pen,C,low,om); z=unpack('Robust',r,p,pen,C,c0,h0)
        rows.append({'Omega':om,'max_abs_x_difference':float(np.max(np.abs(z.x-xsp))),
                     'Expected total nominal':z.expected_total,'Worst residual nominal':z.u.max(),
                     'Worst navigability nominal':z.navigability.min(),
                     **{f'x_{ACTIONS[k]}':z.x[k] for k in range(K)}})
    pd.DataFrame(rows).to_csv(OUT/'robust_grid.csv',index=False)


def cost_sensitivity():
    rows=[]; p=PRIORS['Balanced']; C=PROFILES['Central-response']; pen=penalty_base; B=1.6
    # individual cost perturbations +/- 30%
    global c_base
    original=c_base.copy()
    for k,a in enumerate(ACTIONS):
      for factor in [0.7,0.85,1.0,1.15,1.3]:
        c_base=original.copy(); c_base[k]*=factor
        r,c0,h0=solve_sp(B,p,pen,C); z=unpack('Stochastic',r,p,pen,C,c0,h0)
        rows.append({'Perturbed action':a,'Cost factor':factor,'Expected total':z.expected_total,
                     'Worst residual':z.u.max(),**{f'x_{ACTIONS[j]}':z.x[j] for j in range(K)}})
    c_base=original
    pd.DataFrame(rows).to_csv(OUT/'cost_weight_sensitivity.csv',index=False)



def severity_band_robustness():
    """Check whether central SP and robust reservations depend on the round severity bands."""
    global D
    original_D = D.copy()
    rows=[]
    p=PRIORS['Balanced']; pen=penalty_base.copy(); C=PROFILES['Central-response']; C_low=PROFILES['Lower-response']; B=1.6
    try:
        for gm in [0.25,0.30,0.35]:
            for gs in [0.40,0.50,0.60]:
                for ge in [0.70,0.80,0.90]:
                    D = BASELINE * np.array([gm,gs,ge],dtype=float)
                    rsp,c0,h0=solve_sp(B,p,pen,C)
                    rrob,_,_=solve_rob(B,p,pen,C,C_low,1.5)
                    xsp=rsp.x[:K]; xrob=rrob.x[:K]
                    rows.append({
                        'gamma_moderate':gm,'gamma_severe':gs,'gamma_extreme':ge,
                        'D_moderate':D[0],'D_severe':D[1],'D_extreme':D[2],
                        **{f'stochastic_x_{ACTIONS[k]}':xsp[k] for k in range(K)},
                        **{f'robust_x_{ACTIONS[k]}':xrob[k] for k in range(K)},
                    })
    finally:
        D = original_D
    df=pd.DataFrame(rows)
    df.to_csv(OUT/'severity_band_robustness.csv',index=False)
    return df

def create_figures():
    import matplotlib.pyplot as plt
    summary=pd.read_csv(OUT/'central_policy_summary.csv')
    scen=pd.read_csv(OUT/'central_scenario_results.csv')
    mix=pd.read_csv(OUT/'central_reservation_mix.csv')
    fact=pd.read_csv(OUT/'factorial_policy_results.csv')

    fig,ax=plt.subplots(figsize=(7.2,4.4))
    piv=mix.pivot(index='Policy',columns='Action',values='Reservation fraction')
    piv.plot(kind='bar',ax=ax)
    ax.set_ylabel('Reserved fraction'); ax.set_xlabel(''); ax.set_ylim(0,1.05)
    ax.set_title('Central preparedness portfolios')
    fig.tight_layout(); fig.savefig(FIG/'central_portfolios.png',dpi=300); plt.close(fig)

    fig,ax=plt.subplots(figsize=(7.2,4.4))
    for pol,g in scen.groupby('Policy'):
        ax.plot(g['Scenario'],g['Navigability'],marker='o',label=pol)
    ax.set_ylabel('Preparedness coverage'); ax.set_xlabel(''); ax.set_ylim(0,1)
    ax.tick_params(axis='x',rotation=15); ax.legend(); ax.set_title('Preparedness coverage under exogenous severity bands')
    fig.tight_layout(); fig.savefig(FIG/'central_scenario_navigability.png',dpi=300); plt.close(fig)

    g=fact[(fact['Prior']=='Balanced')&(fact['Penalty multiplier']==1.0)&(fact['Policy']=='Stochastic')]
    fig,ax=plt.subplots(figsize=(7.2,4.4))
    for prof,h in g.groupby('Profile'):
        ax.plot(h['Budget'],h['Worst navigability'],marker='o',label=prof)
    ax.set_xlabel('Normalised preparedness budget'); ax.set_ylabel('Worst-scenario preparedness coverage'); ax.set_ylim(0,1)
    ax.legend(); ax.set_title('Physical response capacity dominates budget value')
    fig.tight_layout(); fig.savefig(FIG/'budget_profile_navigability.png',dpi=300); plt.close(fig)


def source_registry():
    rows=[
      ['Baseline Hormuz flow',20.3,'mb/d','Derived H1-2025 average from EIA Global Energy Security Data: (1Q25 20.4 + 2Q25 20.2)/2','https://www.eia.gov/outlooks/steo/report/energysecurity/article.php'],
      ['Hormuz flow, 1Q26',14.6,'mb/d','EIA STEO energy-security table','https://www.eia.gov/outlooks/steo/report/energysecurity/article.php'],
      ['Hormuz flow, early April 2026',3.8,'mb/d','IEA Oil Market Report April 2026','https://www.iea.org/reports/oil-market-report-april-2026'],
      ['Hormuz flow, early June 2026',12.0,'mb/d','IEA Oil Market Report June 2026','https://www.iea.org/reports/oil-market-report-june-2026'],
      ['Available Saudi-UAE bypass estimate',2.6,'mb/d','EIA Today in Energy, 16 June 2025','https://www.eia.gov/todayinenergy/detail.php?id=65504'],
      ['Combined Saudi-UAE bypass capability',4.7,'mb/d','EIA World Oil Transit Chokepoints','https://www.eia.gov/international/content/analysis/special_topics/World_Oil_Transit_Chokepoints/'],
      ['IEA alternative-route availability range','3.5-5.5','mb/d','IEA Strait of Hormuz factsheet','https://www.iea.org/about/oil-safety-and-emergency-response/strait-of-hormuz'],
      ['IEA collective stock release in May',2.5,'mb/d','IEA commentary, 22 June 2026','https://www.iea.org/commentaries/how-global-oil-supplies-have-readjusted-to-help-fill-the-huge-gap-left-by-the-strait-of-hormuz-shock'],
      ['Observed global inventory draw',3.8,'mb/d','IEA commentary, 22 June 2026','https://www.iea.org/commentaries/how-global-oil-supplies-have-readjusted-to-help-fill-the-huge-gap-left-by-the-strait-of-hormuz-shock'],
      ['Full-year demand reduction estimate',1.1,'mb/d','IEA commentary, 22 June 2026','https://www.iea.org/commentaries/how-global-oil-supplies-have-readjusted-to-help-fill-the-huge-gap-left-by-the-strait-of-hormuz-shock'],
      ['Q2 2026 demand reduction, year-on-year','almost 5','mb/d','IEA commentary, 22 June 2026','https://www.iea.org/commentaries/how-global-oil-supplies-have-readjusted-to-help-fill-the-huge-gap-left-by-the-strait-of-hormuz-shock'],
    ]
    pd.DataFrame(rows,columns=['Quantity','Value','Unit','Source note','URL']).to_csv(OUT/'public_source_registry.csv',index=False)
    pd.DataFrame({'Scenario':SCENARIOS,'Severity fraction':SEVERITY_FRACTIONS,'Planning requirement':D}).to_csv(OUT/'planning_severity_requirements.csv',index=False)
    pd.DataFrame({'Context observation':['1Q26 average','Early June 2026','Early April 2026'],'Retained Hormuz flow':RETAINED_CONTEXT,'Observed reduction fraction':OBSERVED_REDUCTION_FRACTIONS}).to_csv(OUT/'observed_scenario_anchors.csv',index=False)
    pd.DataFrame([{'Profile':name,**dict(zip(ACTIONS,C))} for name,C in PROFILES.items()]).to_csv(OUT/'response_capacity_profiles.csv',index=False)


def environment_and_readme():
    
    try:
        from scipy.optimize._highspy import _core as highs_core
        highs_version=f'{highs_core.HIGHS_VERSION_MAJOR}.{highs_core.HIGHS_VERSION_MINOR}.{highs_core.HIGHS_VERSION_PATCH}'
    except Exception:
        highs_version='not exposed'
    env={'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,
         'platform':platform.platform(),'solver':'scipy.optimize.linprog(method="highs")','highs':highs_version}
    (OUT/'computational_environment.json').write_text(json.dumps(env,indent=2))
    (REP/'core_requirements.txt').write_text(f'numpy=={np.__version__}\npandas=={pd.__version__}\nscipy=={scipy.__version__}\nmatplotlib==3.10.8\n')
    (REP/'CORE_README.md').write_text('''# OMR core empirical replication package\n\nRun `python replication/core_empirical_model.py` from the package root. The script rebuilds all CSV outputs and figures.\n\nEvidence rules:\n- Public observations are stored in `outputs/public_source_registry.csv`.\n- Scenario probabilities, normalised costs, penalties, and budget levels are planning assumptions, not observed facts.\n- The lower, central, and upper response profiles are evidence-bounded stress-test profiles.\n- No practitioner validation is claimed.\n''')


def main():
    t=time.perf_counter(); source_registry(); central_run(); factorial(); cvar_grid(); robust_grid(); cost_sensitivity(); severity_band_robustness(); create_figures(); environment_and_readme()
    summary={
      'runtime_seconds':time.perf_counter()-t,
      'baseline':BASELINE,'severity_fractions':dict(zip(SCENARIOS,SEVERITY_FRACTIONS.tolist())),'requirements':dict(zip(SCENARIOS,D.tolist())),
      'central_budget':1.6,'central_prior':PRIORS['Balanced'].tolist(),
      'number_factorial_solutions':int(len(pd.read_csv(OUT/'factorial_policy_results.csv'))),
    }
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
