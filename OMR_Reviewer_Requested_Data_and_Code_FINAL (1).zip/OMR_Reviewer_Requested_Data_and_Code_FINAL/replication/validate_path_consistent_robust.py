#!/usr/bin/env python3
"""Numerical validation for the path-consistent robust duration model.

This diagnostic samples interior points of the continuous Gamma=1.5 budget polytope
and checks them against the six persistent boundary stress states used in the finite
robust model. It is a numerical stress test, not a proof that all interior states are
dominated for every possible calibration.
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

import duration_aware_hormuz_optimization as m

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
RNG = np.random.default_rng(20260919)


def sample_budget_polytope(n: int, gamma: float = 1.5) -> np.ndarray:
    out = []
    while len(out) < n:
        z = RNG.random((max(2000, n), m.K))
        z = z[z.sum(axis=1) <= gamma + 1e-12]
        out.extend(z.tolist())
    return np.asarray(out[:n], dtype=float)


def main() -> None:
    durations = m.DURATION_PROFILES["Central"]
    readiness = m.READINESS_PROFILES["Central"]
    endurance = 30.0
    zsample = sample_budget_polytope(10000, m.ROBUST_BUDGET)
    rows = []

    for priority_name, priority in m.PHASE_PRIORITY_PROFILES.items():
        robust = m.solve_path_consistent_robust(durations, priority, readiness, endurance)
        x = robust["x"]
        max_obj = -np.inf
        min_cum = np.inf
        min_phase = np.inf
        max_peak = -np.inf
        arg_obj = None
        for z in zsample:
            capacity = m.CENTRAL_CAPACITY - m.CAPACITY_DEVIATION * z
            r = m.solve_recourse_fixed_capacity(x, durations, priority, readiness, endurance, capacity)
            if r["operating_objective"] > max_obj:
                max_obj = r["operating_objective"]
                arg_obj = z.copy()
            min_cum = min(min_cum, r["cumulative_preparedness_coverage"])
            min_phase = min(min_phase, r["worst_phase_preparedness_coverage"])
            max_peak = max(max_peak, r["peak_daily_residual_mbd"])

        vertex_max_obj = robust["worst_operating_loss"]
        rows.append({
            "Priority profile": priority_name,
            "Sample size": len(zsample),
            "Vertex worst operating loss": vertex_max_obj,
            "Largest sampled interior operating loss": max_obj,
            "Vertex minus sampled operating loss": vertex_max_obj - max_obj,
            "Vertex worst cumulative coverage": robust["cumulative_preparedness_coverage"],
            "Smallest sampled interior cumulative coverage": min_cum,
            "Vertex worst-phase coverage": robust["worst_phase_preparedness_coverage"],
            "Smallest sampled interior worst-phase coverage": min_phase,
            "Vertex peak residual": robust["peak_daily_residual_mbd"],
            "Largest sampled interior peak residual": max_peak,
            "Sample argmax z_stock": arg_obj[0],
            "Sample argmax z_bypass": arg_obj[1],
            "Sample argmax z_demand": arg_obj[2],
            "Sample argmax sum z": arg_obj.sum(),
            "Any sampled state worse on operating loss": bool(max_obj > vertex_max_obj + 1e-8),
        })

    df = pd.DataFrame(rows)
    df.to_csv(OUT / "path_consistent_interior_sampling_validation.csv", index=False)
    print(df.to_string(index=False))


if __name__ == "__main__":
    main()
