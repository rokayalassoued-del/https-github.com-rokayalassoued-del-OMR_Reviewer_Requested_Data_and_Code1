#!/usr/bin/env python3
"""Hormuz-only duration-aware preparedness optimization.

Revision for Reviewer 3, Minor Concern 5.

The earlier dynamic robust counterpart applied a separate Bertsimas-Sim capacity
budget in each phase. That representation allowed the identity of the worst capacity
deterioration to change phase-by-phase along a single disruption path. The revised
formulation uses a path-consistent finite robust stress set derived from the maximal
vertices of the same Gamma=1.5 capacity-deterioration budget. Each stress state
represents one persistent mechanism-level deterioration vector that applies across all
three phases. Reservation decisions are made before the stress state is known; phase
activation adapts after the persistent capacity state is observed.

The script performs four tasks:
1. evaluates the static stochastic and static robust portfolios over the three-phase
   Hormuz trajectory;
2. optimizes the preparedness portfolio directly within the nominal multi-period model;
3. solves a path-consistent adaptive robust multi-period model over persistent capacity
   stress states;
4. tests sensitivity to phase priorities, phase durations, readiness ramps, and
   emergency-stock endurance.

Dated 2026 flow observations are used only as contextual plausibility checks.
The optimization requirements are exogenous severity fractions of the common 20.3 mb/d
reference, so realised response cannot determine the requirement. Phase durations and the
piecewise-constant path are transparent planning approximations.
"""
from __future__ import annotations

import json
import platform
import time
from itertools import permutations
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
FIG = ROOT / "figures"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)

ACTIONS = ["Emergency stocks", "Bypass activation", "Demand adaptation"]
PHASES = ["Acute shock", "Restricted operation", "Partial recovery"]
K = len(ACTIONS)
T = len(PHASES)
STOCK = 0

RESERVATION_COST = np.array([0.80, 1.20, 0.60])
ACTIVATION_COST = np.array([0.20, 0.40, 0.15])
CENTRAL_CAPACITY = np.array([2.50, 4.70, 2.50])
LOWER_CAPACITY = np.array([1.25, 2.60, 1.10])
CAPACITY_DEVIATION = np.maximum(CENTRAL_CAPACITY - LOWER_CAPACITY, 0.0)
BUDGET = 1.60
PENALTY = 25.0
ROBUST_BUDGET = 1.50

# Exogenous phase-severity path relative to the consistent 20.3 mb/d first-half-2025
# reference. Observed April-May-June flows are contextual checks only.
BASELINE = 20.3
PHASE_SEVERITY_FRACTIONS = np.array([0.80, 0.50, 0.40])
REQUIREMENT = BASELINE * PHASE_SEVERITY_FRACTIONS
OBSERVED_RETAINED_FLOW_CONTEXT = np.array([3.8, 9.6, 12.0])

DURATION_PROFILES = {
    "Shorter": np.array([15.0, 15.0, 15.0]),
    "Central": np.array([30.0, 31.0, 15.0]),
    "Prolonged": np.array([30.0, 60.0, 30.0]),
}

PHASE_PRIORITY_PROFILES = {
    "Equal": np.array([1.00, 1.00, 1.00]),
    "Moderate early priority": np.array([1.25, 1.10, 1.00]),
    "High early priority": np.array([1.50, 1.25, 1.00]),
}

READINESS_PROFILES = {
    "Fast": np.array([
        [1.00, 0.50, 0.40],
        [1.00, 0.90, 0.85],
        [1.00, 1.00, 1.00],
    ]),
    "Central": np.array([
        [1.00, 0.25, 0.20],
        [1.00, 0.70, 0.60],
        [1.00, 1.00, 1.00],
    ]),
    "Slow": np.array([
        [1.00, 0.10, 0.10],
        [1.00, 0.45, 0.35],
        [1.00, 0.80, 0.75],
    ]),
}


def require_success(result, label: str) -> None:
    if not result.success:
        raise RuntimeError(f"{label}: {result.message}")


def persistent_stress_states(gamma: float = ROBUST_BUDGET) -> list[dict]:
    """Return maximal persistent deterioration states for K=3 and Gamma=1.5.

    The underlying budget polytope is {z in [0,1]^3 : sum(z) <= Gamma}. For the
    central Gamma=1.5 case, the maximal vertices are the six permutations of
    (1, 0.5, 0). Each state is applied unchanged across all phases.
    """
    if K != 3 or abs(gamma - 1.5) > 1e-12:
        raise ValueError("The path-consistent dynamic stress set is calibrated for K=3, Gamma=1.5.")
    states = []
    for idx, p in enumerate(sorted(set(permutations((1.0, 0.5, 0.0))))):
        z = np.asarray(p, dtype=float)
        q = CENTRAL_CAPACITY - CAPACITY_DEVIATION * z
        states.append({
            "id": f"PC{idx+1}",
            "z": z,
            "capacity": q,
        })
    return states


STRESS_STATES = persistent_stress_states()


def phase_metrics(x: np.ndarray, y: np.ndarray, residual: np.ndarray,
                  durations: np.ndarray, requirements: np.ndarray,
                  operating_objective: float, stock_endurance_days: float) -> dict:
    coverage = requirements - residual
    prep = 1.0 - residual / requirements
    cumulative_requirement = float(durations @ requirements)
    cumulative_residual = float(durations @ residual)
    cumulative_coverage = cumulative_requirement - cumulative_residual
    cumulative_prep = cumulative_coverage / cumulative_requirement
    stock_use = float(durations @ y[:, STOCK])
    stock_limit = float(stock_endurance_days * x[STOCK])
    return {
        "x": x,
        "activation": y,
        "residual": residual,
        "coverage": coverage,
        "phase_preparedness_coverage": prep,
        "cumulative_requirement_million_barrels": cumulative_requirement,
        "cumulative_coverage_million_barrels": cumulative_coverage,
        "cumulative_residual_million_barrels": cumulative_residual,
        "cumulative_preparedness_coverage": cumulative_prep,
        "peak_daily_residual_mbd": float(residual.max()),
        "worst_phase_preparedness_coverage": float(prep.min()),
        "stock_fraction_days_used": stock_use,
        "stock_fraction_days_limit": stock_limit,
        "stock_utilization": 0.0 if stock_limit <= 1e-12 else stock_use / stock_limit,
        "operating_objective": float(operating_objective),
        "reservation_cost": float(RESERVATION_COST @ x),
    }


def solve_recourse_fixed_capacity(x: np.ndarray, durations: np.ndarray,
                                  priority: np.ndarray, readiness: np.ndarray,
                                  stock_endurance_days: float,
                                  capacity: np.ndarray) -> dict:
    """Optimize phase activation for fixed reservation and one persistent capacity state."""
    y0 = 0
    u0 = T * K
    n = T * K + T
    obj = np.zeros(n)
    for t in range(T):
        obj[y0 + t*K:y0 + (t+1)*K] = durations[t] * ACTIVATION_COST
        obj[u0 + t] = durations[t] * PENALTY * priority[t]

    A, b = [], []
    for t in range(T):
        for k in range(K):
            row = np.zeros(n)
            row[y0 + t*K + k] = 1.0
            A.append(row)
            b.append(float(readiness[t, k] * x[k]))
        row = np.zeros(n)
        row[y0 + t*K:y0 + (t+1)*K] = -capacity
        row[u0 + t] = -1.0
        A.append(row)
        b.append(-REQUIREMENT[t])

    row = np.zeros(n)
    for t in range(T):
        row[y0 + t*K + STOCK] = durations[t]
    A.append(row)
    b.append(float(stock_endurance_days * x[STOCK]))

    result = linprog(
        obj,
        A_ub=np.asarray(A),
        b_ub=np.asarray(b),
        bounds=[(0.0, None)] * n,
        method="highs",
    )
    require_success(result, "Fixed-capacity dynamic recourse")
    y = result.x[:T*K].reshape(T, K)
    residual = result.x[u0:u0+T]
    return phase_metrics(
        x, y, residual, durations, REQUIREMENT, result.fun, stock_endurance_days
    )


def solve_nominal(durations: np.ndarray, priority: np.ndarray, readiness: np.ndarray,
                  stock_endurance_days: float = 30.0) -> dict:
    """Jointly optimize reservation and phase activation under nominal capacity."""
    x0 = 0
    y0 = K
    u0 = K + T*K
    n = K + T*K + T
    obj = np.zeros(n)
    obj[x0:x0 + K] = RESERVATION_COST
    for t in range(T):
        obj[y0 + t*K:y0 + (t+1)*K] = durations[t] * ACTIVATION_COST
        obj[u0 + t] = durations[t] * PENALTY * priority[t]

    A, b = [], []
    row = np.zeros(n)
    row[x0:x0 + K] = RESERVATION_COST
    A.append(row)
    b.append(BUDGET)

    for t in range(T):
        for k in range(K):
            row = np.zeros(n)
            row[y0 + t*K + k] = 1.0
            row[x0 + k] = -readiness[t, k]
            A.append(row)
            b.append(0.0)
        row = np.zeros(n)
        row[y0 + t*K:y0 + (t+1)*K] = -CENTRAL_CAPACITY
        row[u0 + t] = -1.0
        A.append(row)
        b.append(-REQUIREMENT[t])

    row = np.zeros(n)
    for t in range(T):
        row[y0 + t*K + STOCK] = durations[t]
    row[x0 + STOCK] = -stock_endurance_days
    A.append(row)
    b.append(0.0)

    bounds = [(0.0, 1.0)] * K + [(0.0, None)] * (T*K + T)
    result = linprog(obj, A_ub=np.asarray(A), b_ub=np.asarray(b), bounds=bounds, method="highs")
    require_success(result, "Duration-aware nominal optimization")
    x = result.x[x0:x0 + K]
    y = result.x[y0:y0 + T*K].reshape(T, K)
    residual = result.x[u0:u0 + T]
    m = phase_metrics(x, y, residual, durations, REQUIREMENT,
                      result.fun - RESERVATION_COST @ x, stock_endurance_days)
    m["solver_objective"] = float(result.fun)
    return m


def solve_path_consistent_robust(durations: np.ndarray, priority: np.ndarray,
                                 readiness: np.ndarray,
                                 stock_endurance_days: float = 30.0) -> dict:
    """Adaptive robust model over persistent path-consistent capacity stress states.

    x is chosen before the persistent deterioration state is known. For each stress state
    omega, phase activations y[omega,t,k] and residuals u[omega,t] adapt to the realized
    mechanism-level capacities. rho upper-bounds the total operating loss across all
    stress states. The objective minimizes reservation burden plus worst-case operating
    loss.
    """
    W = len(STRESS_STATES)
    x0 = 0
    rho_idx = K
    block0 = K + 1
    block = T*K + T
    n = block0 + W * block

    obj = np.zeros(n)
    obj[x0:x0 + K] = RESERVATION_COST
    obj[rho_idx] = 1.0

    A, b = [], []
    row = np.zeros(n)
    row[x0:x0 + K] = RESERVATION_COST
    A.append(row)
    b.append(BUDGET)

    for w, state in enumerate(STRESS_STATES):
        capacity = state["capacity"]
        off = block0 + w * block
        y0 = off
        u0 = off + T*K

        for t in range(T):
            for k in range(K):
                row = np.zeros(n)
                row[y0 + t*K + k] = 1.0
                row[x0 + k] = -readiness[t, k]
                A.append(row)
                b.append(0.0)
            row = np.zeros(n)
            row[y0 + t*K:y0 + (t+1)*K] = -capacity
            row[u0 + t] = -1.0
            A.append(row)
            b.append(-REQUIREMENT[t])

        row = np.zeros(n)
        for t in range(T):
            row[y0 + t*K + STOCK] = durations[t]
        row[x0 + STOCK] = -stock_endurance_days
        A.append(row)
        b.append(0.0)

        # Worst-path operating-loss epigraph.
        row = np.zeros(n)
        for t in range(T):
            row[y0 + t*K:y0 + (t+1)*K] = durations[t] * ACTIVATION_COST
            row[u0 + t] = durations[t] * PENALTY * priority[t]
        row[rho_idx] = -1.0
        A.append(row)
        b.append(0.0)

    bounds = [(0.0, 1.0)] * K + [(0.0, None)] * (n - K)
    result = linprog(obj, A_ub=np.asarray(A), b_ub=np.asarray(b), bounds=bounds, method="highs")
    require_success(result, "Path-consistent duration-aware robust optimization")

    x = result.x[x0:x0 + K]
    scenario_metrics = []
    for w, state in enumerate(STRESS_STATES):
        off = block0 + w * block
        y0 = off
        u0 = off + T*K
        y = result.x[y0:y0 + T*K].reshape(T, K)
        residual = result.x[u0:u0 + T]
        operating = sum(
            durations[t] * (ACTIVATION_COST @ y[t] + PENALTY * priority[t] * residual[t])
            for t in range(T)
        )
        m = phase_metrics(x, y, residual, durations, REQUIREMENT,
                          operating, stock_endurance_days)
        m["stress_state_id"] = state["id"]
        m["z"] = state["z"]
        m["capacity"] = state["capacity"]
        scenario_metrics.append(m)

    worst_operating = max(scenario_metrics, key=lambda m: m["operating_objective"])
    return {
        "x": x,
        "reservation_cost": float(RESERVATION_COST @ x),
        "solver_objective": float(result.fun),
        "worst_operating_loss": float(result.x[rho_idx]),
        "cumulative_preparedness_coverage": min(m["cumulative_preparedness_coverage"] for m in scenario_metrics),
        "worst_phase_preparedness_coverage": min(m["worst_phase_preparedness_coverage"] for m in scenario_metrics),
        "peak_daily_residual_mbd": max(m["peak_daily_residual_mbd"] for m in scenario_metrics),
        "scenario_metrics": scenario_metrics,
        "representative_worst_state": worst_operating,
    }


def evaluate_fixed_nominal(x: np.ndarray, durations: np.ndarray, priority: np.ndarray,
                           readiness: np.ndarray, stock_endurance_days: float) -> dict:
    m = solve_recourse_fixed_capacity(
        x, durations, priority, readiness, stock_endurance_days, CENTRAL_CAPACITY
    )
    m["solver_objective"] = float(m["operating_objective"] + RESERVATION_COST @ x)
    return m


def evaluate_fixed_path_robust(x: np.ndarray, durations: np.ndarray, priority: np.ndarray,
                               readiness: np.ndarray, stock_endurance_days: float) -> dict:
    scenario_metrics = []
    for state in STRESS_STATES:
        m = solve_recourse_fixed_capacity(
            x, durations, priority, readiness, stock_endurance_days, state["capacity"]
        )
        m["stress_state_id"] = state["id"]
        m["z"] = state["z"]
        m["capacity"] = state["capacity"]
        scenario_metrics.append(m)
    worst_operating = max(scenario_metrics, key=lambda m: m["operating_objective"])
    return {
        "x": x,
        "reservation_cost": float(RESERVATION_COST @ x),
        "solver_objective": float(RESERVATION_COST @ x + worst_operating["operating_objective"]),
        "cumulative_preparedness_coverage": min(m["cumulative_preparedness_coverage"] for m in scenario_metrics),
        "worst_phase_preparedness_coverage": min(m["worst_phase_preparedness_coverage"] for m in scenario_metrics),
        "peak_daily_residual_mbd": max(m["peak_daily_residual_mbd"] for m in scenario_metrics),
        "scenario_metrics": scenario_metrics,
        "representative_worst_state": worst_operating,
    }


def primary_optimal_acute_stock_range(x: np.ndarray, durations: np.ndarray,
                                      priority: np.ndarray, readiness: np.ndarray,
                                      stock_endurance_days: float,
                                      capacity: np.ndarray = CENTRAL_CAPACITY,
                                      tol: float = 1e-7) -> tuple[float, float, float]:
    """Range of acute stock activation among primary-objective-optimal recourse schedules."""
    base = solve_recourse_fixed_capacity(
        x, durations, priority, readiness, stock_endurance_days, capacity
    )
    optimum = base["operating_objective"]

    y0 = 0
    u0 = T*K
    n = T*K + T
    A, b = [], []
    for t in range(T):
        for k in range(K):
            row = np.zeros(n)
            row[y0 + t*K + k] = 1.0
            A.append(row)
            b.append(float(readiness[t, k] * x[k]))
        row = np.zeros(n)
        row[y0 + t*K:y0 + (t+1)*K] = -capacity
        row[u0 + t] = -1.0
        A.append(row)
        b.append(-REQUIREMENT[t])
    row = np.zeros(n)
    for t in range(T):
        row[y0 + t*K + STOCK] = durations[t]
    A.append(row)
    b.append(float(stock_endurance_days * x[STOCK]))

    # Preserve the primary optimum to numerical tolerance.
    row = np.zeros(n)
    for t in range(T):
        row[y0 + t*K:y0 + (t+1)*K] = durations[t] * ACTIVATION_COST
        row[u0 + t] = durations[t] * PENALTY * priority[t]
    A.append(row)
    b.append(float(optimum + tol))

    c_min = np.zeros(n)
    c_min[y0 + STOCK] = 1.0
    r_min = linprog(c_min, A_ub=np.asarray(A), b_ub=np.asarray(b),
                    bounds=[(0.0, None)]*n, method="highs")
    require_success(r_min, "Minimum acute-stock tie-break diagnostic")

    c_max = np.zeros(n)
    c_max[y0 + STOCK] = -1.0
    r_max = linprog(c_max, A_ub=np.asarray(A), b_ub=np.asarray(b),
                    bounds=[(0.0, None)]*n, method="highs")
    require_success(r_max, "Maximum acute-stock tie-break diagnostic")
    return float(optimum), float(r_min.x[y0 + STOCK]), float(r_max.x[y0 + STOCK])


def load_static_portfolios() -> dict[str, np.ndarray]:
    source = pd.read_csv(OUT / "central_reservation_mix.csv")
    portfolios = {}
    for policy in ["Stochastic", "Robust"]:
        portfolios[f"Static {policy.lower()}"] = np.array([
            float(source[(source["Policy"] == policy) & (source["Action"] == action)]["Reservation fraction"].iloc[0])
            for action in ACTIONS
        ])
    return portfolios


def summary_row(policy: str, design: str, condition: str, metrics: dict,
                priority_name: str, duration_name: str, readiness_name: str,
                stock_endurance: float) -> dict:
    return {
        "Policy": policy,
        "Design": design,
        "Evaluation condition": condition,
        "Priority profile": priority_name,
        "Duration profile": duration_name,
        "Readiness profile": readiness_name,
        "Stock endurance days": stock_endurance,
        "Reservation cost": float(metrics["reservation_cost"]),
        "Cumulative preparedness coverage": float(metrics["cumulative_preparedness_coverage"]),
        "Peak daily residual (mb/d)": float(metrics["peak_daily_residual_mbd"]),
        "Worst phase preparedness coverage": float(metrics["worst_phase_preparedness_coverage"]),
        "Solver objective": float(metrics["solver_objective"]),
        **{f"Reservation - {ACTIONS[k]}": float(metrics["x"][k]) for k in range(K)},
    }


def append_nominal_phase_rows(rows: list[dict], policy: str, design: str,
                              metrics: dict, durations: np.ndarray,
                              priority_name: str, duration_name: str,
                              readiness_name: str, stock_endurance: float) -> None:
    for t, phase in enumerate(PHASES):
        rows.append({
            "Policy": policy,
            "Design": design,
            "Evaluation condition": "Nominal capacity",
            "Capacity stress state": "Nominal",
            "Priority profile": priority_name,
            "Duration profile": duration_name,
            "Readiness profile": readiness_name,
            "Stock endurance days": stock_endurance,
            "Phase": phase,
            "Phase order": t + 1,
            "Duration days": float(durations[t]),
            "Planning requirement (mb/d)": float(REQUIREMENT[t]),
            "Coverage (mb/d-equivalent)": float(metrics["coverage"][t]),
            "Residual gap (mb/d-equivalent)": float(metrics["residual"][t]),
            "Preparedness coverage": float(metrics["phase_preparedness_coverage"][t]),
            **{f"Activation - {ACTIONS[k]}": float(metrics["activation"][t, k]) for k in range(K)},
        })


def append_robust_phase_rows(rows: list[dict], policy: str, design: str,
                             metrics: dict, durations: np.ndarray,
                             priority_name: str, duration_name: str,
                             readiness_name: str, stock_endurance: float) -> None:
    # Report the persistent stress state that maximizes the primary operating-loss objective.
    m = metrics["representative_worst_state"]
    for t, phase in enumerate(PHASES):
        rows.append({
            "Policy": policy,
            "Design": design,
            "Evaluation condition": "Path-consistent robust stress set",
            "Capacity stress state": m["stress_state_id"],
            "Priority profile": priority_name,
            "Duration profile": duration_name,
            "Readiness profile": readiness_name,
            "Stock endurance days": stock_endurance,
            "Phase": phase,
            "Phase order": t + 1,
            "Duration days": float(durations[t]),
            "Planning requirement (mb/d)": float(REQUIREMENT[t]),
            "Coverage (mb/d-equivalent)": float(m["coverage"][t]),
            "Residual gap (mb/d-equivalent)": float(m["residual"][t]),
            "Preparedness coverage": float(m["phase_preparedness_coverage"][t]),
            **{f"Activation - {ACTIONS[k]}": float(m["activation"][t, k]) for k in range(K)},
        })


def central_experiment() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    durations = DURATION_PROFILES["Central"]
    priority = PHASE_PRIORITY_PROFILES["Equal"]
    readiness = READINESS_PROFILES["Central"]
    endurance = 30.0
    static = load_static_portfolios()
    rows, phase_rows = [], []

    for name, x in static.items():
        m_nom = evaluate_fixed_nominal(x, durations, priority, readiness, endurance)
        rows.append(summary_row(name, "Static portfolio", "Nominal capacity", m_nom,
                                "Equal", "Central", "Central", endurance))
        append_nominal_phase_rows(phase_rows, name, "Static portfolio", m_nom,
                                  durations, "Equal", "Central", "Central", endurance)

        m_rob = evaluate_fixed_path_robust(x, durations, priority, readiness, endurance)
        rows.append(summary_row(name, "Static portfolio", "Path-consistent robust stress set", m_rob,
                                "Equal", "Central", "Central", endurance))
        append_robust_phase_rows(phase_rows, name, "Static portfolio", m_rob,
                                 durations, "Equal", "Central", "Central", endurance)

    dyn_nom = solve_nominal(durations, priority, readiness, endurance)
    rows.append(summary_row("Duration-aware nominal", "Joint multi-period optimization",
                            "Nominal capacity", dyn_nom, "Equal", "Central", "Central", endurance))
    append_nominal_phase_rows(phase_rows, "Duration-aware nominal", "Joint multi-period optimization",
                              dyn_nom, durations, "Equal", "Central", "Central", endurance)
    dyn_nom_rob = evaluate_fixed_path_robust(dyn_nom["x"], durations, priority, readiness, endurance)
    rows.append(summary_row("Duration-aware nominal", "Joint multi-period optimization",
                            "Path-consistent robust stress set", dyn_nom_rob,
                            "Equal", "Central", "Central", endurance))
    append_robust_phase_rows(phase_rows, "Duration-aware nominal", "Joint multi-period optimization",
                             dyn_nom_rob, durations, "Equal", "Central", "Central", endurance)

    dyn_rob = solve_path_consistent_robust(durations, priority, readiness, endurance)
    dyn_rob_nom = evaluate_fixed_nominal(dyn_rob["x"], durations, priority, readiness, endurance)
    rows.append(summary_row("Duration-aware robust", "Path-consistent adaptive robust optimization",
                            "Nominal capacity", dyn_rob_nom,
                            "Equal", "Central", "Central", endurance))
    append_nominal_phase_rows(phase_rows, "Duration-aware robust",
                              "Path-consistent adaptive robust optimization", dyn_rob_nom,
                              durations, "Equal", "Central", "Central", endurance)
    rows.append(summary_row("Duration-aware robust", "Path-consistent adaptive robust optimization",
                            "Path-consistent robust stress set", dyn_rob,
                            "Equal", "Central", "Central", endurance))
    append_robust_phase_rows(phase_rows, "Duration-aware robust",
                             "Path-consistent adaptive robust optimization", dyn_rob,
                             durations, "Equal", "Central", "Central", endurance)

    # Degeneracy diagnostic requested by Reviewer 3: exact acute-stock activation is not
    # unique for the fixed static-robust portfolio under equal priorities.
    diag_rows = []
    for name, x in static.items():
        opt, low, high = primary_optimal_acute_stock_range(
            x, durations, priority, readiness, endurance
        )
        diag_rows.append({
            "Policy": name,
            "Primary operating objective": opt,
            "Minimum acute-stock activation among primary-optimal schedules": low,
            "Maximum acute-stock activation among primary-optimal schedules": high,
            "Reserved stock fraction": float(x[STOCK]),
        })

    return pd.DataFrame(rows), pd.DataFrame(phase_rows), pd.DataFrame(diag_rows)


def sensitivity_experiment() -> pd.DataFrame:
    rows = []
    static = load_static_portfolios()
    for priority_name, priority in PHASE_PRIORITY_PROFILES.items():
        for duration_name, durations in DURATION_PROFILES.items():
            for readiness_name, readiness in READINESS_PROFILES.items():
                for endurance in [15.0, 30.0, 60.0]:
                    nominal = solve_nominal(durations, priority, readiness, endurance)
                    rows.append({
                        "Policy": "Duration-aware nominal",
                        "Evaluation condition": "Nominal capacity",
                        "Priority profile": priority_name,
                        "Duration profile": duration_name,
                        "Readiness profile": readiness_name,
                        "Stock endurance days": endurance,
                        "Cumulative preparedness coverage": nominal["cumulative_preparedness_coverage"],
                        "Peak daily residual (mb/d)": nominal["peak_daily_residual_mbd"],
                        "Worst phase preparedness coverage": nominal["worst_phase_preparedness_coverage"],
                        **{f"Reservation - {ACTIONS[k]}": float(nominal["x"][k]) for k in range(K)},
                    })

                    robust = solve_path_consistent_robust(durations, priority, readiness, endurance)
                    rows.append({
                        "Policy": "Duration-aware robust",
                        "Evaluation condition": "Path-consistent robust stress set",
                        "Priority profile": priority_name,
                        "Duration profile": duration_name,
                        "Readiness profile": readiness_name,
                        "Stock endurance days": endurance,
                        "Cumulative preparedness coverage": robust["cumulative_preparedness_coverage"],
                        "Peak daily residual (mb/d)": robust["peak_daily_residual_mbd"],
                        "Worst phase preparedness coverage": robust["worst_phase_preparedness_coverage"],
                        **{f"Reservation - {ACTIONS[k]}": float(robust["x"][k]) for k in range(K)},
                    })

                    # Static comparators are retained as nominal fixed-portfolio benchmarks.
                    for policy_name, x in static.items():
                        m = evaluate_fixed_nominal(x, durations, priority, readiness, endurance)
                        rows.append({
                            "Policy": policy_name,
                            "Evaluation condition": "Nominal capacity",
                            "Priority profile": priority_name,
                            "Duration profile": duration_name,
                            "Readiness profile": readiness_name,
                            "Stock endurance days": endurance,
                            "Cumulative preparedness coverage": m["cumulative_preparedness_coverage"],
                            "Peak daily residual (mb/d)": m["peak_daily_residual_mbd"],
                            "Worst phase preparedness coverage": m["worst_phase_preparedness_coverage"],
                            **{f"Reservation - {ACTIONS[k]}": float(m["x"][k]) for k in range(K)},
                        })
    return pd.DataFrame(rows)


def priority_sensitivity_table() -> pd.DataFrame:
    durations = DURATION_PROFILES["Central"]
    readiness = READINESS_PROFILES["Central"]
    endurance = 30.0
    rows = []
    for priority_name, priority in PHASE_PRIORITY_PROFILES.items():
        robust = solve_path_consistent_robust(durations, priority, readiness, endurance)
        rows.append({
            "Priority profile": priority_name,
            **{f"Reservation - {ACTIONS[k]}": float(robust["x"][k]) for k in range(K)},
            "Worst-case cumulative preparedness coverage": robust["cumulative_preparedness_coverage"],
            "Worst-case worst-phase preparedness coverage": robust["worst_phase_preparedness_coverage"],
            "Worst-case peak residual (mb/d)": robust["peak_daily_residual_mbd"],
            "Robust objective": robust["solver_objective"],
        })
    return pd.DataFrame(rows)


def stress_state_table() -> pd.DataFrame:
    rows = []
    for state in STRESS_STATES:
        rows.append({
            "Stress state": state["id"],
            "z_stock": state["z"][0],
            "z_bypass": state["z"][1],
            "z_demand": state["z"][2],
            "Capacity - Emergency stocks": state["capacity"][0],
            "Capacity - Bypass activation": state["capacity"][1],
            "Capacity - Demand adaptation": state["capacity"][2],
            "Gamma": ROBUST_BUDGET,
            "Persistence": "Same deterioration vector in all phases",
        })
    return pd.DataFrame(rows)


def make_figures(summary: pd.DataFrame, phases: pd.DataFrame) -> None:
    nominal = summary[summary["Evaluation condition"] == "Nominal capacity"].copy()
    order = ["Static stochastic", "Static robust", "Duration-aware nominal", "Duration-aware robust"]
    nominal["Policy"] = pd.Categorical(nominal["Policy"], order, ordered=True)
    nominal = nominal.sort_values("Policy")

    fig, ax = plt.subplots(figsize=(8.7, 4.8))
    ax.bar(nominal["Policy"], nominal["Cumulative preparedness coverage"])
    ax.set_ylabel("Cumulative preparedness coverage")
    ax.set_ylim(0, max(0.4, nominal["Cumulative preparedness coverage"].max() * 1.18))
    ax.set_title("Hormuz: static and duration-aware portfolios")
    ax.tick_params(axis="x", rotation=15)
    fig.tight_layout()
    fig.savefig(FIG / "hormuz_duration_aware_policy_comparison.png", dpi=300)
    plt.close(fig)

    p = phases[phases["Evaluation condition"] == "Nominal capacity"].copy()
    fig, ax = plt.subplots(figsize=(8.7, 4.8))
    for policy in order:
        g = p[p["Policy"] == policy].sort_values("Phase order")
        ax.plot(g["Phase"], g["Preparedness coverage"], marker="o", label=policy)
    ax.set_ylabel("Phase preparedness coverage")
    ax.set_ylim(0, 0.80)
    ax.set_title("Hormuz: preparedness coverage across disruption phases")
    ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "hormuz_duration_aware_phase_navigability.png", dpi=300)
    plt.close(fig)


def main() -> None:
    start = time.perf_counter()
    summary, phases, degeneracy = central_experiment()
    sensitivity = sensitivity_experiment()
    priority_table = priority_sensitivity_table()
    stress_states = stress_state_table()

    summary.to_csv(OUT / "hormuz_duration_aware_policy_summary.csv", index=False)
    phases.to_csv(OUT / "hormuz_duration_aware_phase_results.csv", index=False)
    sensitivity.to_csv(OUT / "hormuz_duration_aware_sensitivity.csv", index=False)
    priority_table.to_csv(OUT / "path_consistent_priority_sensitivity.csv", index=False)
    stress_states.to_csv(OUT / "path_consistent_capacity_stress_states.csv", index=False)
    degeneracy.to_csv(OUT / "activation_degeneracy_diagnostic.csv", index=False)

    trajectory = pd.DataFrame({
        "Phase": PHASES,
        "Phase order": [1, 2, 3],
        "Planning requirement (mb/d)": REQUIREMENT,
        "Central duration (days)": DURATION_PROFILES["Central"],
        "Severity status": ["Exogenous planning assumption"] * 3,
        "Observed retained flow for context (mb/d)": OBSERVED_RETAINED_FLOW_CONTEXT,
        "Duration evidence status": ["Planning approximation"] * 3,
        "Within-phase path": ["Piecewise-constant planning approximation"] * 3,
    })
    trajectory.to_csv(OUT / "hormuz_duration_aware_trajectory.csv", index=False)

    make_figures(summary, phases)

    robust_rows = sensitivity[sensitivity["Policy"] == "Duration-aware robust"].copy()
    nominal_rows = sensitivity[sensitivity["Policy"] == "Duration-aware nominal"].copy()
    robust_vectors = robust_rows[[f"Reservation - {a}" for a in ACTIONS]].to_numpy()
    nominal_vectors = nominal_rows[[f"Reservation - {a}" for a in ACTIONS]].to_numpy()
    diagnostics = {
        "robust_distinct_reservation_vectors": int(len(np.unique(np.round(robust_vectors, 6), axis=0))),
        "nominal_distinct_reservation_vectors": int(len(np.unique(np.round(nominal_vectors, 6), axis=0))),
        "robust_stock_selection_fraction": float(np.mean(robust_vectors[:, STOCK] > 1e-8)),
        "nominal_stock_selection_fraction": float(np.mean(nominal_vectors[:, STOCK] > 1e-8)),
    }

    metadata = {
        "runtime_seconds": time.perf_counter() - start,
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "matplotlib": matplotlib.__version__,
        "solver": "HiGHS via scipy.optimize.linprog",
        "event_scope": "Hormuz only",
        "robust_dynamic_formulation": "Path-consistent adaptive finite-stress-set robust model",
        "robust_budget_gamma": ROBUST_BUDGET,
        "persistent_capacity_stress_states": len(STRESS_STATES),
        "central_priority": "Equal",
        "central_duration_profile": "Central",
        "central_readiness_profile": "Central",
        "central_stock_endurance_days": 30.0,
        "sensitivity_policy_evaluations": int(len(sensitivity)),
        **diagnostics,
    }
    (OUT / "hormuz_duration_aware_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
