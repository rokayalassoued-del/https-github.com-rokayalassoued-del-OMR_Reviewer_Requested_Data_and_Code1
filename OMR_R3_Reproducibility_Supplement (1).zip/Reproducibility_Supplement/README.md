# OMR reproducibility supplement — current revision

This supplementary archive accompanies the revised manuscript **Preparedness Planning for Maritime Chokepoint Disruptions: A Duration-Aware Stochastic and Robust Optimization Framework** (OMRA-D-26-00553). It contains the analysis scripts, model inputs, public-source registries, outputs, figures, and recorded computational environment used to document the study.

## Model calibration and prior-stage analyses

The static requirement is response-independent: `D_s = gamma_s * F0`, with `F0 = 20.3` mb/d and severity fractions `(0.30, 0.50, 0.80)`. The duration-aware requirements use `(0.80, 0.50, 0.40)`. Observed 2026 throughput values are used for contextual plausibility checks, not as demand requirements. The duration-aware robust model uses persistent mechanism-level stress over the three-phase path, represented by six boundary stress states. The corresponding input assumptions and validation limits are described in `TECHNICAL_VALIDATION_REPORT.md`.

## Current-round replication outputs

- `outputs/reviewer3_priority_nominal_vs_robust.csv`: nominal cumulative, worst-case cumulative, worst-phase, and peak residual metrics for the three phase-priority portfolios.
- `outputs/reviewer3_robust_statewise_phase_recourses.csv`: fixed-portfolio, independently optimized recourse for 3 priority profiles × 6 persistent stress states × 3 phases (54 rows).
- `outputs/factorial_policy_results.csv` and `outputs/policy_distinctness.csv`: 3 capacity profiles × 4 probability priors × 6 budgets × 3 penalty multipliers = 216 configurations; 648 stochastic/CVaR/robust solution rows.
- `outputs/cvar_grid.csv`: 25 central CVaR settings (5 confidence levels × 5 risk weights).
- `outputs/cvar_breakpoint_280_original_grid_R2.csv`: the original 280-setting breakpoint grid, re-executed with the current `F0 = 20.3` mb/d calibration; 7 confidence levels × 8 risk weights × 5 acute-state penalty multipliers.
- `historical_cvar_grid_reference_2026_08/`: the retained August 2026 historical breakpoint script and result, which used the earlier `F0 = 20.9` mb/d calibration. These outputs are kept separate from the current-calibration results.
- `outputs/computational_environment.json`: Python, NumPy, pandas, SciPy/HiGHS versions used for the static analyses.

## Reproduction

Run from the `Reproducibility_Supplement/` directory after installing the dependencies listed in `replication/requirements.txt` and `replication/core_requirements.txt`:

```bash
python replication/core_empirical_model.py
python replication/temporal_validation_2020_2026.py
python replication/duration_aware_hormuz_optimization.py
python replication/validate_path_consistent_robust.py
python replication/replicate_cvar_280_original_grid_R2.py
python replication/verify_reviewer3_statewise_and_nominal.py
```

The last two scripts reproduce the current-round 280-point CVaR check and the independent statewise recourse evaluation. Scripts write CSV/JSON outputs to `outputs/`, figures to `figures/`, and the duration-aware workbook to `data/`. For additional details, see `replication/README_REPLICATION.md` and `replication/CORE_README.md`.

Scenario probabilities, costs, penalties and stress parameters are modelling assumptions; the historical and public-source records are identified separately. The numerical interior-stress check is a sampled diagnostic and does not establish an analytical equivalence theorem.
