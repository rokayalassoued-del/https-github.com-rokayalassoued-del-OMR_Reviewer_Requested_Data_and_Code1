# Technical validation report — current manuscript revision

## Purpose

This report documents the response-independent disruption requirement and the persistent path-consistent robust formulation established during the earlier revision rounds, together with the computational results retained in the current manuscript. It also identifies the new replication outputs supporting the present review.

## Response-independent requirement

The revised static requirement is

`D_s = gamma_s F0`,

with `F0 = 20.3` mb/d and central severity fractions `(0.30, 0.50, 0.80)`, giving requirements `(6.09, 10.15, 16.24)` mb/d-equivalent. Dated 2026 Hormuz throughput observations are retained only for contextual comparison and do not enter `D_s`.

The duration-aware path is built independently in the same way with severity fractions `(0.80, 0.50, 0.40)`, giving phase requirements `(16.24, 10.15, 8.12)` mb/d-equivalent. The early-April, May-low and early-June observed flows remain contextual checks only.

This construction prevents bypass or demand adjustment from both affecting observed throughput and then receiving a second credit in the adequacy constraint.

## Static central results after rerun

Central balanced-prior, central-response, `B = 1.60`:

- Deterministic reservation: `(0.000, 0.764, 1.000)`; nominal expected index `154.222`; adverse worst coverage `0.233`.
- Stochastic reservation: `(0.000, 0.833, 1.000)`; nominal expected index `147.949`; adverse worst coverage `0.244`.
- CVaR reservation: `(0.000, 0.833, 1.000)`; nominal expected index `147.949`; adverse worst coverage `0.244`.
- Robust reservation: `(0.780, 0.465, 0.697)`; nominal expected index `160.050`; adverse expected index `199.563`; adverse worst coverage `0.272`.

Relative to the stochastic solution, the robust solution has an `8.18%` nominal expected-index premium and a `5.72%` lower adverse-capacity expected index.

## Severity-band robustness

The moderate severity fraction was varied over `{0.25, 0.30, 0.35}`, the severe fraction over `{0.40, 0.50, 0.60}`, and the extreme fraction over `{0.70, 0.80, 0.90}`, producing 27 combinations.

Across all 27 combinations:

- stochastic reservation remained `(0.000, 0.833, 1.000)`;
- robust reservation remained `(0.780488, 0.464576, 0.696864)` to solver precision.

The full output is `outputs/severity_band_robustness.csv`.

## Path-consistent dynamic robust formulation

The duration-aware robust model uses one mechanism-level capacity deterioration state over the complete acute-restricted-recovery path. With three mechanisms and `Omega = 1.5`, the finite boundary stress set contains the six permutations of `(1, 0.5, 0)`. Reservation decisions are common across stress states; phase activations and residuals adapt after the persistent state is observed.

Under equal phase priorities, central duration/readiness and 30 days of stock endurance:

- Static stochastic: reservation `(0.000, 0.833, 1.000)`, worst-case cumulative coverage `0.181`, worst-phase coverage `0.056`, peak residual `15.34` mb/d.
- Static robust: reservation `(0.780, 0.465, 0.697)`, worst-case cumulative coverage `0.175`, worst-phase coverage `0.034`, peak residual `15.69` mb/d.
- Duration-aware nominal: reservation `(0.000, 1.000, 0.667)`, nominal cumulative coverage `0.296`.
- Duration-aware robust: reservation `(0.000, 0.833, 1.000)`, worst-case cumulative coverage `0.181`, worst-phase coverage `0.056`, peak residual `15.34` mb/d.

With moderate early priority, the robust reservation becomes approximately `(0.878, 0.406, 0.684)`, worst-phase coverage rises to `0.111`, worst-case cumulative coverage is `0.174`, and peak residual falls to `14.43` mb/d.

## Numerical stress-set diagnostic

For each central phase-priority setting, 10,000 interior points satisfying the same `Omega = 1.5` budget were sampled. None produced a larger full-path operating loss than the six boundary states. This is a numerical diagnostic, not a proof of equivalence with the complete continuous uncertainty set.

## Software

The active scripts use Python, NumPy, pandas, SciPy/HiGHS and Matplotlib. Exact versions are stored in `outputs/computational_environment.json`, `outputs/temporal_computational_environment.json`, and the pinned requirements files.

## Current-round Reviewer 3 replication checks

The current package includes a state-wise optimal recourse evaluation for fixed robust reservation portfolios. The archived output `outputs/reviewer3_robust_statewise_phase_recourses.csv` contains 54 phase-level rows (three priority settings, six persistent stress states, three phases), and `outputs/reviewer3_priority_nominal_vs_robust.csv` records both nominal and worst-case portfolio coverage. These outputs can be reproduced using `python replication/verify_reviewer3_statewise_and_nominal.py`.

The exact historical 280-point CVaR breakpoint grid uses 7 confidence levels `{0.50, 0.70, 0.80, 0.90, 0.95, 0.975, 0.99}`, 8 risk weights `{0.10, 0.50, 1, 2, 5, 10, 25, 50}`, and 5 acute-state penalty multipliers `{1, 2, 4, 8, 16}`. The archive contains both the historical August 2026 results (earlier `F0 = 20.9` calibration) and the exact-grid rerun under the current `F0 = 20.3` calibration. The latter is generated by `python replication/replicate_cvar_280_original_grid_R2.py` and saved as `outputs/cvar_breakpoint_280_original_grid_R2.csv`. The two calibrations are retained as distinct experiments.

The factorial static experiment combines three response profiles, four prior distributions, six budget levels, and three penalty scales, producing 216 configurations and 648 policy-solve rows. The conditions and variables associated with these experiments are defined in the manuscript and replication scripts.
