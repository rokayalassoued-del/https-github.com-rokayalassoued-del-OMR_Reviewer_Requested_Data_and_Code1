# Technical and Editorial Validation Report

## Scope
The final seven-section package was audited for structure, grammar, terminology, internal consistency, LaTeX integrity, citations, tables, figures, and reproducibility references.

## Editorial corrections completed
- Replaced the obsolete introduction roadmap that still described the former ten-section structure.
- Removed a duplicated phrase in the conclusion.
- Replaced the last visible use of `cumulative navigability` with `cumulative preparedness coverage`.
- Updated the supporting workbook headers and chart title to use `preparedness coverage` terminology.
- Corrected the historical calibration figure so the 20.7 mb/d reference is labelled `4Q25 baseline`.
- Reconciled the response letter with the clean-and-marked submission package and removed an unsupported claim about the abstract.
- Updated the title-page abstract and reviewer response to use the revised coverage terminology.
- Distinguished the historical calibration subsection from the retrospective results subsection.
- Corrected US-English consistency in the budget figure (`Normalized`, not `Normalised`).
- Updated the response letter so the managerial implications are described accurately as a dedicated subsection within the combined discussion section.
- Separated the single-state deterministic comparison from the formal expected-value stochastic-programming benchmark. The expected-value problem reproduces the stochastic first-stage portfolio, so formal VSS is 0.000; the 2.240 (1.48%) improvement is retained only as the gain over the controlled single-state benchmark.
- Reconciled response-letter section, equation, and table locations with the final seven-section manuscript and Tables 1--21.

## Structural checks
- Main sections: 7.
- Cross-references: no undefined references.
- Citation keys: 42 cited references and 42 bibliography entries; no missing, duplicated, or uncited entries.
- The manuscript roadmap now matches the seven-section organization.

## Language and terminology checks
- No adjacent duplicated words remain.
- `Preparedness coverage ratio` is used consistently in the manuscript interpretation.
- The residual internal label and figure filenames containing `navigability` are retained only for source compatibility and are not visible as the interpretation of the indicator.
- Claims concerning CVaR, robustness, historical transfer, and practitioner validation remain qualified.

## LaTeX and visual checks
- Clean and marked manuscripts, response letter, and title page compile successfully.
- No fatal errors, undefined citations, undefined references, or overfull boxes remain.
- Clean manuscript length: 36 pages; marked manuscript length: 36 pages.
- All 36 pages of the marked manuscript were rendered and inspected for clipping, overlap, missing figures, broken glyphs, and table overflow; none was observed.
- Hyperlinks are enabled with hidden link styling.

## Reproducibility checks
- The core empirical script was rerun after the figure-language correction.
- An independent QA rerun under Python 3.12.13 reproduced all unchanged numerical outputs; the archived environment and runtime records preserve the documented reference run under Python 3.13.5.
- The package retains the scripts, pinned requirements, input registries, raw outputs, workbook, generated figures, environment records, and reproduction instructions.

## External-source spot checks
The current EIA chokepoint page, the EIA June 2025 Hormuz page, and the IEA April and June 2026 Oil Market Report pages were located on their official domains. Bibliographic consistency within the manuscript was verified in full; the report does not claim independent content verification of every cited article.

## Final reference and template re-audit — 7 August 2026

- Abstract is 239 words and complies with the OMR 150–250 word limit.
- Bibliography rechecked: 42 unique cited keys and 42 bibliography entries; no missing or uncited records.
- Corrected Dolgui and Ivanov (2021): removed an incorrectly listed third author.
- Added access dates to institutional EIA, IEA, and UNCTAD web sources.
- Title page reduced to identifying metadata plus Statements and Declarations; the abstract and keywords remain only in the anonymized manuscript.
- Double-blind scan found no author name, institutional email, or identifying affiliation string outside the separate title page.
- The main manuscript uses `\documentclass[pdflatex,sn-basic,NameDate]{sn-jnl}` and embedded `bibitem` references.
- All four LaTeX deliverables compile with `pdflatex` without fatal errors, undefined citations/references, or overfull boxes.
