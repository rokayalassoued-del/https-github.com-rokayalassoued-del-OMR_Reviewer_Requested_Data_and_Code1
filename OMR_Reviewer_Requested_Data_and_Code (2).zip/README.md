# Reviewer data and replication archive

This anonymous archive accompanies the revised manuscript. It contains the public-source inputs, planning assumptions, executable analysis code, raw and summarized computational outputs, results workbook, generated figures, environment records, and technical validation report referenced in the manuscript and response letter.

## Contents

- `data/`: historical periods, temporal source registry, 2026 validation states, and the results workbook.
- `outputs/`: central results, robustness and sensitivity analyses, benchmark metrics, temporal-validation results, duration-aware results, source registries, and environment metadata.
- `replication/`: three Python scripts, pinned requirements, and detailed reproduction instructions.
- `figures/`: figures generated from the archived inputs and outputs.
- `TECHNICAL_VALIDATION_REPORT.md`: editorial, computational, and reproducibility checks.

## Reproduction

From the archive root, install the dependencies listed in `replication/requirements.txt` and `replication/core_requirements.txt`, then run:

```bash
python replication/core_empirical_model.py
python replication/temporal_validation_2020_2026.py
python replication/duration_aware_hormuz_optimization.py
```

The scripts write regenerated CSV and JSON outputs to `outputs/` and regenerated figures to `figures/`.

## Interpretation

Public observations and their source records are separated from planning assumptions. Scenario probabilities, normalized costs, penalties, budgets, phase durations, phase priorities, readiness fractions, actor weights, and stock-endurance settings are model inputs rather than observed facts. The response profiles are evidence-bounded stress-test profiles. The archive does not claim practitioner or field validation.
