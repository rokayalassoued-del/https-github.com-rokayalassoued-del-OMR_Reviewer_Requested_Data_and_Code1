#!/usr/bin/env python3
"""Hormuz-only duration-aware preparedness optimization.

This script replaces the earlier cross-corridor fixed-policy transfer exercise.
It performs four tasks:
1. evaluates the static stochastic and static robust portfolios over a three-phase
   Hormuz trajectory;
2. optimizes the preparedness portfolio directly within the multi-period model;
3. constructs a budgeted-robust multi-period counterpart for capacity uncertainty;
4. tests sensitivity to phase priorities, phase durations, readiness ramps, and
   emergency-stock endurance.

The dated 2026 flow estimates are used as phase-severity anchors. Phase durations
and the piecewise-constant path are transparent planning approximations, not
claimed as continuously observed daily averages.
"""
from __future__ import annotations

import json
import platform
import time
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
FIG = ROOT / "figures"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)

ACTIONS = ["Emergency stocks", "Bypass activation", "Demand adaptation"]
PHASES = ["Acute shock", "Restricted operation", "Partial recovery"]
K = len(ACTIONS)
T = len(PHASES)
STOCK = 0

# Same transparent planning inputs as the revised core experiment.
RESERVATION_COST = np.array([0.80, 1.20, 0.60])
ACTIVATION_COST = np.array([0.20, 0.40, 0.15])
CENTRAL_CAPACITY = np.array([2.50, 4.70, 2.50])
LOWER_CAPACITY = np.array([1.25, 2.60, 1.10])
BUDGET = 1.60
PENALTY = 25.0
ROBUST_BUDGET = 1.50

# Severity anchors: gross shortfalls relative to the 20.9 mb/d reference flow.
REQUIREMENT = np.array([17.1, 11.3, 8.9])

# Central piecewise-constant planning trajectory. The durations approximate the
# calendar intervals represented by early-April, May, and early-June estimates.
DURATION_PROFILES = {
    "Shorter": np.array([15.0, 15.0, 15.0]),
    "Central": np.array([30.0, 31.0, 15.0]),
    "Prolonged": np.array([30.0, 60.0, 30.0]),
}

# Equal weights are the neutral central case. Early-protection profiles are
# reported as managerial-preference sensitivity tests.
PHASE_PRIORITY_PROFILES = {
    "Equal": np.array([1.00, 1.00, 1.00]),
    "Moderate early priority": np.array([1.25, 1.10, 1.00]),
    "High early priority": np.array([1.50, 1.25, 1.00]),
}

READINESS_PROFILES = {
    "Fast": np.array([
        [1.00, 0.50, 0.40],
        [1.00, 0.90, 0.85],
        [1.00, 1.00, 1.00],
    ]),
    "Central": np.array([
        [1.00, 0.25, 0.20],
        [1.00, 0.70, 0.60],
        [1.00, 1.00, 1.00],
    ]),
    "Slow": np.array([
        [1.00, 0.10, 0.10],
        [1.00, 0.45, 0.35],
        [1.00, 0.80, 0.75],
    ]),
}


def require_success(result, label: str) -> None:
    if not result.success:
        raise RuntimeError(f"{label}: {result.message}")


def _metrics(x: np.ndarray, y: np.ndarray, residual: np.ndarray,
             durations: np.ndarray, requirements: np.ndarray,
             solver_objective: float, stock_endurance_days: float) -> dict:
    coverage = requirements - residual
    nav = 1.0 - residual / requirements
    cumulative_requirement = float(durations @ requirements)
    cumulative_residual = float(durations @ residual)
    cumulative_coverage = cumulative_requirement - cumulative_residual
    cumulative_nav = cumulative_coverage / cumulative_requirement
    stock_use = float(durations @ y[:, STOCK])
    stock_limit = float(stock_endurance_days * x[STOCK])
    return {
        "x": x,
        "activation": y,
        "residual": residual,
        "coverage": coverage,
        "phase_navigability": nav,
        "cumulative_requirement_million_barrels": cumulative_requirement,
        "cumulative_coverage_million_barrels": cumulative_coverage,
        "cumulative_residual_million_barrels": cumulative_residual,
        "cumulative_navigability": cumulative_nav,
        "peak_daily_residual_mbd": float(residual.max()),
        "worst_phase_navigability": float(nav.min()),
        "stock_fraction_days_used": stock_use,
        "stock_fraction_days_limit": stock_limit,
        "stock_utilization": 0.0 if stock_limit <= 1e-12 else stock_use / stock_limit,
        "solver_objective": float(solver_objective),
        "reservation_cost": float(RESERVATION_COST @ x),
    }


def solve_nominal(durations: np.ndarray, priority: np.ndarray, readiness: np.ndarray,
                  stock_endurance_days: float = 30.0) -> dict:
    """Jointly optimize reservation x and phase activation y under central capacity."""
    x0 = 0
    y0 = K
    u0 = K + T * K
    n = K + T * K + T
    obj = np.zeros(n)
    obj[x0:x0 + K] = RESERVATION_COST
    for t in range(T):
        obj[y0 + t*K:y0 + (t+1)*K] = durations[t] * ACTIVATION_COST
        obj[u0 + t] = durations[t] * PENALTY * priority[t]

    A, b = [], []
    row = np.zeros(n)
    row[x0:x0 + K] = RESERVATION_COST
    A.append(row); b.append(BUDGET)

    for t in range(T):
        for k in range(K):
            row = np.zeros(n)
            row[y0 + t*K + k] = 1.0
            row[x0 + k] = -readiness[t, k]
            A.append(row); b.append(0.0)
        row = np.zeros(n)
        row[y0 + t*K:y0 + (t+1)*K] = -CENTRAL_CAPACITY
        row[u0 + t] = -1.0
        A.append(row); b.append(-REQUIREMENT[t])

    # Cumulative stock endurance scales with the reserved stock fraction.
    row = np.zeros(n)
    for t in range(T):
        row[y0 + t*K + STOCK] = durations[t]
    row[x0 + STOCK] = -stock_endurance_days
    A.append(row); b.append(0.0)

    bounds = [(0.0, 1.0)] * K + [(0.0, None)] * (T*K + T)
    result = linprog(obj, A_ub=np.asarray(A), b_ub=np.asarray(b), bounds=bounds, method="highs")
    require_success(result, "Duration-aware nominal optimization")
    x = result.x[x0:x0 + K]
    y = result.x[y0:y0 + T*K].reshape(T, K)
    residual = result.x[u0:u0 + T]
    return _metrics(x, y, residual, durations, REQUIREMENT, result.fun, stock_endurance_days)


def solve_robust(durations: np.ndarray, priority: np.ndarray, readiness: np.ndarray,
                 stock_endurance_days: float = 30.0,
                 robust_budget: float = ROBUST_BUDGET) -> dict:
    """Jointly optimize reservation and activation with budgeted capacity uncertainty."""
    delta = np.maximum(CENTRAL_CAPACITY - LOWER_CAPACITY, 0.0)
    x0 = 0
    y0 = K
    u0 = K + T*K
    theta0 = u0 + T
    r0 = theta0 + T
    n = r0 + T*K
    obj = np.zeros(n)
    obj[x0:x0 + K] = RESERVATION_COST
    for t in range(T):
        obj[y0 + t*K:y0 + (t+1)*K] = durations[t] * ACTIVATION_COST
        obj[u0 + t] = durations[t] * PENALTY * priority[t]

    A, b = [], []
    row = np.zeros(n)
    row[x0:x0 + K] = RESERVATION_COST
    A.append(row); b.append(BUDGET)

    for t in range(T):
        for k in range(K):
            row = np.zeros(n)
            row[y0 + t*K + k] = 1.0
            row[x0 + k] = -readiness[t, k]
            A.append(row); b.append(0.0)

        # Bertsimas-Sim budgeted robust counterpart of the phase coverage constraint.
        row = np.zeros(n)
        row[y0 + t*K:y0 + (t+1)*K] = -CENTRAL_CAPACITY
        row[u0 + t] = -1.0
        row[theta0 + t] = robust_budget
        row[r0 + t*K:r0 + (t+1)*K] = 1.0
        A.append(row); b.append(-REQUIREMENT[t])

        for k in range(K):
            row = np.zeros(n)
            row[y0 + t*K + k] = delta[k]
            row[theta0 + t] = -1.0
            row[r0 + t*K + k] = -1.0
            A.append(row); b.append(0.0)

    row = np.zeros(n)
    for t in range(T):
        row[y0 + t*K + STOCK] = durations[t]
    row[x0 + STOCK] = -stock_endurance_days
    A.append(row); b.append(0.0)

    bounds = [(0.0, 1.0)] * K + [(0.0, None)] * (T*K + T + T + T*K)
    result = linprog(obj, A_ub=np.asarray(A), b_ub=np.asarray(b), bounds=bounds, method="highs")
    require_success(result, "Duration-aware robust optimization")
    x = result.x[x0:x0 + K]
    y = result.x[y0:y0 + T*K].reshape(T, K)
    residual = result.x[u0:u0 + T]
    return _metrics(x, y, residual, durations, REQUIREMENT, result.fun, stock_endurance_days)


def evaluate_fixed(x: np.ndarray, durations: np.ndarray, priority: np.ndarray,
                   readiness: np.ndarray, stock_endurance_days: float,
                   robust: bool = False) -> dict:
    """Optimize phase activation for a fixed static portfolio."""
    if not robust:
        y0 = 0
        u0 = T*K
        n = T*K + T
        obj = np.zeros(n)
        for t in range(T):
            obj[y0 + t*K:y0 + (t+1)*K] = durations[t] * ACTIVATION_COST
            obj[u0 + t] = durations[t] * PENALTY * priority[t]
        A, b = [], []
        for t in range(T):
            for k in range(K):
                row = np.zeros(n); row[y0 + t*K + k] = 1.0
                A.append(row); b.append(float(readiness[t, k] * x[k]))
            row = np.zeros(n)
            row[y0 + t*K:y0 + (t+1)*K] = -CENTRAL_CAPACITY
            row[u0 + t] = -1.0
            A.append(row); b.append(-REQUIREMENT[t])
        row = np.zeros(n)
        for t in range(T): row[y0 + t*K + STOCK] = durations[t]
        A.append(row); b.append(float(stock_endurance_days * x[STOCK]))
        result = linprog(obj, A_ub=np.asarray(A), b_ub=np.asarray(b),
                         bounds=[(0.0, None)]*n, method="highs")
        require_success(result, "Fixed nominal dynamic evaluation")
        y = result.x[:T*K].reshape(T, K)
        residual = result.x[u0:u0+T]
        metrics = _metrics(x, y, residual, durations, REQUIREMENT,
                           result.fun + RESERVATION_COST @ x, stock_endurance_days)
        return metrics

    delta = np.maximum(CENTRAL_CAPACITY - LOWER_CAPACITY, 0.0)
    y0 = 0
    u0 = T*K
    theta0 = u0 + T
    r0 = theta0 + T
    n = r0 + T*K
    obj = np.zeros(n)
    for t in range(T):
        obj[y0 + t*K:y0 + (t+1)*K] = durations[t] * ACTIVATION_COST
        obj[u0 + t] = durations[t] * PENALTY * priority[t]
    A, b = [], []
    for t in range(T):
        for k in range(K):
            row = np.zeros(n); row[y0 + t*K + k] = 1.0
            A.append(row); b.append(float(readiness[t, k] * x[k]))
        row = np.zeros(n)
        row[y0 + t*K:y0 + (t+1)*K] = -CENTRAL_CAPACITY
        row[u0 + t] = -1.0
        row[theta0+t] = ROBUST_BUDGET
        row[r0+t*K:r0+(t+1)*K] = 1.0
        A.append(row); b.append(-REQUIREMENT[t])
        for k in range(K):
            row = np.zeros(n)
            row[y0+t*K+k] = delta[k]
            row[theta0+t] = -1.0
            row[r0+t*K+k] = -1.0
            A.append(row); b.append(0.0)
    row = np.zeros(n)
    for t in range(T): row[y0 + t*K + STOCK] = durations[t]
    A.append(row); b.append(float(stock_endurance_days * x[STOCK]))
    result = linprog(obj, A_ub=np.asarray(A), b_ub=np.asarray(b),
                     bounds=[(0.0, None)]*n, method="highs")
    require_success(result, "Fixed robust dynamic evaluation")
    y = result.x[:T*K].reshape(T, K)
    residual = result.x[u0:u0+T]
    return _metrics(x, y, residual, durations, REQUIREMENT,
                    result.fun + RESERVATION_COST @ x, stock_endurance_days)


def load_static_portfolios() -> dict[str, np.ndarray]:
    source = pd.read_csv(OUT / "central_reservation_mix.csv")
    portfolios = {}
    for policy in ["Stochastic", "Robust"]:
        portfolios[f"Static {policy.lower()}"] = np.array([
            float(source[(source["Policy"] == policy) & (source["Action"] == action)]["Reservation fraction"].iloc[0])
            for action in ACTIONS
        ])
    return portfolios


def append_results(rows: list[dict], phase_rows: list[dict], policy: str,
                   design: str, condition: str, metrics: dict,
                   durations: np.ndarray, priority_name: str,
                   duration_name: str, readiness_name: str,
                   stock_endurance: float) -> None:
    rows.append({
        "Policy": policy,
        "Design": design,
        "Evaluation condition": condition,
        "Priority profile": priority_name,
        "Duration profile": duration_name,
        "Readiness profile": readiness_name,
        "Stock endurance days": stock_endurance,
        "Reservation cost": metrics["reservation_cost"],
        "Cumulative requirement (million barrels)": metrics["cumulative_requirement_million_barrels"],
        "Cumulative coverage (million barrels)": metrics["cumulative_coverage_million_barrels"],
        "Cumulative residual (million barrels)": metrics["cumulative_residual_million_barrels"],
        "Cumulative preparedness coverage": metrics["cumulative_navigability"],
        "Peak daily residual (mb/d)": metrics["peak_daily_residual_mbd"],
        "Worst-phase preparedness coverage": metrics["worst_phase_navigability"],
        "Stock utilization": metrics["stock_utilization"],
        "Solver objective": metrics["solver_objective"],
        **{f"Reservation - {ACTIONS[k]}": float(metrics["x"][k]) for k in range(K)},
    })
    for t, phase in enumerate(PHASES):
        phase_rows.append({
            "Policy": policy,
            "Design": design,
            "Evaluation condition": condition,
            "Priority profile": priority_name,
            "Duration profile": duration_name,
            "Readiness profile": readiness_name,
            "Stock endurance days": stock_endurance,
            "Phase": phase,
            "Phase order": t + 1,
            "Duration days": float(durations[t]),
            "Gross shortfall (mb/d)": float(REQUIREMENT[t]),
            "Coverage (mb/d)": float(metrics["coverage"][t]),
            "Residual (mb/d)": float(metrics["residual"][t]),
            "Preparedness coverage": float(metrics["phase_navigability"][t]),
            **{f"Activation - {ACTIONS[k]}": float(metrics["activation"][t, k]) for k in range(K)},
        })


def central_experiment() -> tuple[pd.DataFrame, pd.DataFrame]:
    durations = DURATION_PROFILES["Central"]
    priority = PHASE_PRIORITY_PROFILES["Equal"]
    readiness = READINESS_PROFILES["Central"]
    endurance = 30.0
    static = load_static_portfolios()
    rows, phase_rows = [], []

    for name, x in static.items():
        m_nom = evaluate_fixed(x, durations, priority, readiness, endurance, robust=False)
        append_results(rows, phase_rows, name, "Static portfolio", "Nominal capacity",
                       m_nom, durations, "Equal", "Central", "Central", endurance)
        m_rob = evaluate_fixed(x, durations, priority, readiness, endurance, robust=True)
        append_results(rows, phase_rows, name, "Static portfolio", "Budgeted robust guarantee",
                       m_rob, durations, "Equal", "Central", "Central", endurance)

    dyn_nom = solve_nominal(durations, priority, readiness, endurance)
    append_results(rows, phase_rows, "Duration-aware nominal", "Joint multi-period optimization",
                   "Nominal capacity", dyn_nom, durations, "Equal", "Central", "Central", endurance)
    dyn_nom_rob = evaluate_fixed(dyn_nom["x"], durations, priority, readiness, endurance, robust=True)
    append_results(rows, phase_rows, "Duration-aware nominal", "Joint multi-period optimization",
                   "Budgeted robust guarantee", dyn_nom_rob, durations, "Equal", "Central", "Central", endurance)

    dyn_rob = solve_robust(durations, priority, readiness, endurance)
    dyn_rob_nom = evaluate_fixed(dyn_rob["x"], durations, priority, readiness, endurance, robust=False)
    append_results(rows, phase_rows, "Duration-aware robust", "Joint robust multi-period optimization",
                   "Nominal capacity", dyn_rob_nom, durations, "Equal", "Central", "Central", endurance)
    append_results(rows, phase_rows, "Duration-aware robust", "Joint robust multi-period optimization",
                   "Budgeted robust guarantee", dyn_rob, durations, "Equal", "Central", "Central", endurance)

    return pd.DataFrame(rows), pd.DataFrame(phase_rows)


def sensitivity_experiment() -> pd.DataFrame:
    rows = []
    static = load_static_portfolios()
    for priority_name, priority in PHASE_PRIORITY_PROFILES.items():
        for duration_name, durations in DURATION_PROFILES.items():
            for readiness_name, readiness in READINESS_PROFILES.items():
                for endurance in [15.0, 30.0, 60.0]:
                    for model_name, solver in [
                        ("Duration-aware nominal", solve_nominal),
                        ("Duration-aware robust", solve_robust),
                    ]:
                        m = solver(durations, priority, readiness, endurance)
                        rows.append({
                            "Policy": model_name,
                            "Priority profile": priority_name,
                            "Duration profile": duration_name,
                            "Readiness profile": readiness_name,
                            "Stock endurance days": endurance,
                            "Cumulative preparedness coverage": m["cumulative_navigability"],
                            "Peak daily residual (mb/d)": m["peak_daily_residual_mbd"],
                            "Worst-phase preparedness coverage": m["worst_phase_navigability"],
                            "Cumulative residual (million barrels)": m["cumulative_residual_million_barrels"],
                            **{f"Reservation - {ACTIONS[k]}": float(m["x"][k]) for k in range(K)},
                        })
                    # Evaluate the two static portfolios under the same nominal condition.
                    for policy_name, x in static.items():
                        m = evaluate_fixed(x, durations, priority, readiness, endurance, robust=False)
                        rows.append({
                            "Policy": policy_name,
                            "Priority profile": priority_name,
                            "Duration profile": duration_name,
                            "Readiness profile": readiness_name,
                            "Stock endurance days": endurance,
                            "Cumulative preparedness coverage": m["cumulative_navigability"],
                            "Peak daily residual (mb/d)": m["peak_daily_residual_mbd"],
                            "Worst-phase preparedness coverage": m["worst_phase_navigability"],
                            "Cumulative residual (million barrels)": m["cumulative_residual_million_barrels"],
                            **{f"Reservation - {ACTIONS[k]}": float(m["x"][k]) for k in range(K)},
                        })
    return pd.DataFrame(rows)


def make_figures(summary: pd.DataFrame, phases: pd.DataFrame) -> None:
    nominal = summary[summary["Evaluation condition"] == "Nominal capacity"].copy()
    order = ["Static stochastic", "Static robust", "Duration-aware nominal", "Duration-aware robust"]
    nominal["Policy"] = pd.Categorical(nominal["Policy"], order, ordered=True)
    nominal = nominal.sort_values("Policy")

    fig, ax = plt.subplots(figsize=(8.7, 4.8))
    ax.bar(nominal["Policy"], nominal["Cumulative preparedness coverage"])
    ax.set_ylabel("Cumulative preparedness coverage")
    ax.set_ylim(0, max(0.4, nominal["Cumulative preparedness coverage"].max() * 1.18))
    ax.set_title("Hormuz 2026: static and duration-aware portfolios")
    ax.tick_params(axis="x", rotation=15)
    fig.tight_layout()
    fig.savefig(FIG / "hormuz_duration_aware_policy_comparison.png", dpi=300)
    plt.close(fig)

    p = phases[phases["Evaluation condition"] == "Nominal capacity"].copy()
    fig, ax = plt.subplots(figsize=(8.7, 4.8))
    for policy in order:
        g = p[p["Policy"] == policy].sort_values("Phase order")
        ax.plot(g["Phase"], g["Preparedness coverage"], marker="o", label=policy)
    ax.set_ylabel("Phase preparedness coverage")
    ax.set_ylim(0, 0.65)
    ax.set_title("Hormuz 2026: preparedness coverage across disruption phases")
    ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "hormuz_duration_aware_phase_navigability.png", dpi=300)
    plt.close(fig)


def main() -> None:
    start = time.perf_counter()
    summary, phases = central_experiment()
    sensitivity = sensitivity_experiment()
    summary.to_csv(OUT / "hormuz_duration_aware_policy_summary.csv", index=False)
    phases.to_csv(OUT / "hormuz_duration_aware_phase_results.csv", index=False)
    sensitivity.to_csv(OUT / "hormuz_duration_aware_sensitivity.csv", index=False)

    trajectory = pd.DataFrame({
        "Phase": PHASES,
        "Phase order": [1, 2, 3],
        "Severity anchor (mb/d shortfall)": REQUIREMENT,
        "Central duration (days)": DURATION_PROFILES["Central"],
        "Severity evidence status": ["Reported dated estimate"] * 3,
        "Duration evidence status": [
            "Calendar-based planning approximation",
            "Calendar-based planning approximation",
            "Calendar-based planning approximation",
        ],
        "Within-phase path": ["Piecewise-constant planning approximation"] * 3,
    })
    trajectory.to_csv(OUT / "hormuz_duration_aware_trajectory.csv", index=False)

    make_figures(summary, phases)
    metadata = {
        "runtime_seconds": time.perf_counter() - start,
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "matplotlib": matplotlib.__version__,
        "solver": "HiGHS via scipy.optimize.linprog",
        "event_scope": "Hormuz 2026 only",
        "central_priority": "Equal",
        "central_duration_profile": "Central",
        "central_readiness_profile": "Central",
        "central_stock_endurance_days": 30.0,
        "sensitivity_configurations": int(len(sensitivity)),
    }
    (OUT / "hormuz_duration_aware_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
