# Replication instructions

Run the scripts from the package root in this order:

1. `python replication/core_empirical_model.py`
2. `python replication/temporal_validation_2020_2026.py`
3. `python replication/duration_aware_hormuz_optimization.py`

Install the pinned dependencies from `replication/requirements.txt` and `replication/core_requirements.txt` as applicable. The scripts write regenerated CSV and JSON files to `outputs/` and manuscript figures to `figures/`.

The dynamic experiment uses the exact priority, duration, readiness, and stock-endurance profiles reported in Table 8 of the clean manuscript.
