#!/usr/bin/env python3
"""Historical operating-envelope calibration and retrospective temporal transfer for the Hormuz study.

The script uses nine aggregated pre-2026 periods to characterize historical downside flow deviations. It freezes each first-stage portfolio and evaluates it on four later reported 2026 states. The 2026
states have different temporal resolutions. They are reported separately and
are not assigned empirical probabilities.
"""
from __future__ import annotations

import json
import platform
import time
from dataclasses import dataclass
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"
FIG = ROOT / "figures"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)

ACTIONS = ["Emergency stocks", "Bypass activation", "Demand adaptation"]
K = len(ACTIONS)
BASELINE_MAIN = 20.7
BUDGET = 1.60
RESERVATION_WEIGHTS = np.array([0.80, 1.20, 0.60])
ACTIVATION_WEIGHTS = np.array([0.20, 0.40, 0.15])
CENTRAL_CAPACITY = np.array([2.50, 4.70, 2.50])
LOWER_CAPACITY = np.array([1.25, 2.60, 1.10])
PENALTY_MAIN = 25.0
CVAR_ALPHA = 0.90
CVAR_WEIGHT = 0.50
ROBUST_BUDGET = 1.50


@dataclass
class Policy:
    name: str
    x: np.ndarray
    solver_objective: float


def require_success(result, label: str) -> None:
    if not result.success:
        raise RuntimeError(f"{label}: {result.message}")


def solve_historical_mean(D, probabilities, penalty, capacity):
    """Expected-value deterministic benchmark for the temporal experiment."""
    target = float(probabilities @ D)
    penalty_mean = float(probabilities @ penalty)
    n = 2 * K + 1
    obj = np.r_[RESERVATION_WEIGHTS, ACTIVATION_WEIGHTS, penalty_mean]
    A, b = [], []

    row = np.zeros(n)
    row[:K] = RESERVATION_WEIGHTS
    A.append(row)
    b.append(BUDGET)

    for k in range(K):
        row = np.zeros(n)
        row[K + k] = 1.0
        row[k] = -1.0
        A.append(row)
        b.append(0.0)

    row = np.zeros(n)
    row[K : 2 * K] = -capacity
    row[-1] = -1.0
    A.append(row)
    b.append(-target)

    result = linprog(
        obj,
        A_ub=np.asarray(A),
        b_ub=np.asarray(b),
        bounds=[(0.0, 1.0)] * K + [(0.0, None)] * (K + 1),
        method="highs",
    )
    require_success(result, "Historical mean benchmark")
    return result


def solve_stochastic(D, probabilities, penalty, capacity):
    S = len(D)
    n = K + S * K + S
    obj = np.zeros(n)
    obj[:K] = RESERVATION_WEIGHTS
    for s in range(S):
        obj[K + s * K : K + (s + 1) * K] = probabilities[s] * ACTIVATION_WEIGHTS
        obj[K + S * K + s] = probabilities[s] * penalty[s]

    A, b = [], []
    row = np.zeros(n)
    row[:K] = RESERVATION_WEIGHTS
    A.append(row)
    b.append(BUDGET)

    for s in range(S):
        for k in range(K):
            row = np.zeros(n)
            row[K + s * K + k] = 1.0
            row[k] = -1.0
            A.append(row)
            b.append(0.0)
        row = np.zeros(n)
        row[K + s * K : K + (s + 1) * K] = -capacity
        row[K + S * K + s] = -1.0
        A.append(row)
        b.append(-D[s])

    result = linprog(
        obj,
        A_ub=np.asarray(A),
        b_ub=np.asarray(b),
        bounds=[(0.0, 1.0)] * K + [(0.0, None)] * (S * K + S),
        method="highs",
    )
    require_success(result, "Historical stochastic program")
    return result


def solve_cvar(D, probabilities, penalty, capacity):
    S = len(D)
    base = K + S * K + S
    eta = base
    xi0 = base + 1
    n = base + 1 + S

    obj = np.zeros(n)
    obj[:K] = RESERVATION_WEIGHTS
    for s in range(S):
        obj[K + s * K : K + (s + 1) * K] = probabilities[s] * ACTIVATION_WEIGHTS
        obj[K + S * K + s] = probabilities[s] * penalty[s]
    obj[eta] = CVAR_WEIGHT
    obj[xi0 : xi0 + S] = CVAR_WEIGHT * probabilities / (1.0 - CVAR_ALPHA)

    A, b = [], []
    row = np.zeros(n)
    row[:K] = RESERVATION_WEIGHTS
    A.append(row)
    b.append(BUDGET)

    for s in range(S):
        for k in range(K):
            row = np.zeros(n)
            row[K + s * K + k] = 1.0
            row[k] = -1.0
            A.append(row)
            b.append(0.0)

        row = np.zeros(n)
        row[K + s * K : K + (s + 1) * K] = -capacity
        row[K + S * K + s] = -1.0
        A.append(row)
        b.append(-D[s])

        row = np.zeros(n)
        row[K + s * K : K + (s + 1) * K] = ACTIVATION_WEIGHTS
        row[K + S * K + s] = penalty[s]
        row[eta] = -1.0
        row[xi0 + s] = -1.0
        A.append(row)
        b.append(0.0)

    bounds = (
        [(0.0, 1.0)] * K
        + [(0.0, None)] * (S * K + S)
        + [(None, None)]
        + [(0.0, None)] * S
    )
    result = linprog(obj, A_ub=np.asarray(A), b_ub=np.asarray(b), bounds=bounds, method="highs")
    require_success(result, "Historical CVaR program")
    return result


def solve_robust(D, probabilities, penalty, capacity, lower_capacity):
    S = len(D)
    deviation = np.maximum(capacity - lower_capacity, 0.0)
    base = K + S * K + S
    theta0 = base
    r0 = base + S
    n = r0 + S * K

    obj = np.zeros(n)
    obj[:K] = RESERVATION_WEIGHTS
    for s in range(S):
        obj[K + s * K : K + (s + 1) * K] = probabilities[s] * ACTIVATION_WEIGHTS
        obj[K + S * K + s] = probabilities[s] * penalty[s]

    A, b = [], []
    row = np.zeros(n)
    row[:K] = RESERVATION_WEIGHTS
    A.append(row)
    b.append(BUDGET)

    for s in range(S):
        for k in range(K):
            row = np.zeros(n)
            row[K + s * K + k] = 1.0
            row[k] = -1.0
            A.append(row)
            b.append(0.0)

        row = np.zeros(n)
        row[K + s * K : K + (s + 1) * K] = -capacity
        row[K + S * K + s] = -1.0
        row[theta0 + s] = ROBUST_BUDGET
        row[r0 + s * K : r0 + (s + 1) * K] = 1.0
        A.append(row)
        b.append(-D[s])

        for k in range(K):
            row = np.zeros(n)
            row[K + s * K + k] = deviation[k]
            row[theta0 + s] = -1.0
            row[r0 + s * K + k] = -1.0
            A.append(row)
            b.append(0.0)

    result = linprog(
        obj,
        A_ub=np.asarray(A),
        b_ub=np.asarray(b),
        bounds=[(0.0, 1.0)] * K + [(0.0, None)] * (S * K + S + S + S * K),
        method="highs",
    )
    require_success(result, "Historical robust program")
    return result


def evaluate_fixed_policy(x, requirement, capacity, penalty):
    n = K + 1
    obj = np.r_[ACTIVATION_WEIGHTS, penalty]
    A, b = [], []
    for k in range(K):
        row = np.zeros(n)
        row[k] = 1.0
        A.append(row)
        b.append(x[k])

    row = np.zeros(n)
    row[:K] = -capacity
    row[-1] = -1.0
    A.append(row)
    b.append(-requirement)

    result = linprog(
        obj,
        A_ub=np.asarray(A),
        b_ub=np.asarray(b),
        bounds=[(0.0, None)] * n,
        method="highs",
    )
    require_success(result, "Fixed-policy evaluation")
    activation = result.x[:K]
    residual = float(result.x[-1])
    coverage = float(requirement - residual)
    navigability = 1.0 if requirement <= 1e-12 else float(coverage / requirement)
    total = float(RESERVATION_WEIGHTS @ x + ACTIVATION_WEIGHTS @ activation + penalty * residual)
    return activation, residual, coverage, navigability, total


def solve_oracle(requirement, capacity, penalty):
    n = 2 * K + 1
    obj = np.r_[RESERVATION_WEIGHTS, ACTIVATION_WEIGHTS, penalty]
    A, b = [], []

    row = np.zeros(n)
    row[:K] = RESERVATION_WEIGHTS
    A.append(row)
    b.append(BUDGET)

    for k in range(K):
        row = np.zeros(n)
        row[K + k] = 1.0
        row[k] = -1.0
        A.append(row)
        b.append(0.0)

    row = np.zeros(n)
    row[K : 2 * K] = -capacity
    row[-1] = -1.0
    A.append(row)
    b.append(-requirement)

    result = linprog(
        obj,
        A_ub=np.asarray(A),
        b_ub=np.asarray(b),
        bounds=[(0.0, 1.0)] * K + [(0.0, None)] * (K + 1),
        method="highs",
    )
    require_success(result, "Statewise oracle")
    return float(result.fun)


def calibrate_policies(requirement, probabilities, penalty):
    solvers = {
        "Historical mean": solve_historical_mean(requirement, probabilities, penalty, CENTRAL_CAPACITY),
        "Stochastic": solve_stochastic(requirement, probabilities, penalty, CENTRAL_CAPACITY),
        "CVaR": solve_cvar(requirement, probabilities, penalty, CENTRAL_CAPACITY),
        "Robust": solve_robust(requirement, probabilities, penalty, CENTRAL_CAPACITY, LOWER_CAPACITY),
    }
    return [Policy(name, result.x[:K].copy(), float(result.fun)) for name, result in solvers.items()]


def temporal_experiment(baseline=BASELINE_MAIN, weighting="duration", penalty_level=PENALTY_MAIN):
    historical = pd.read_csv(DATA / "historical_periods_2020_2025.csv")
    validation = pd.read_csv(DATA / "validation_states_2026.csv")

    historical["gross_shortfall_mb_d"] = np.maximum(0.0, baseline - historical["flow_mb_d"])
    validation["gross_shortfall_mb_d"] = np.maximum(0.0, baseline - validation["flow_mb_d"])

    if weighting == "duration":
        probabilities = historical["duration_months"].to_numpy(float)
    elif weighting == "equal":
        probabilities = np.ones(len(historical), dtype=float)
    else:
        raise ValueError(f"Unknown weighting scheme: {weighting}")
    probabilities /= probabilities.sum()
    historical["calibration_probability"] = probabilities

    D = historical["gross_shortfall_mb_d"].to_numpy(float)
    penalty = np.full(len(D), penalty_level, dtype=float)
    policies = calibrate_policies(D, probabilities, penalty)

    reservation_rows = []
    training_rows = []
    validation_rows = []
    for policy in policies:
        first_cost = float(RESERVATION_WEIGHTS @ policy.x)
        for k, action in enumerate(ACTIONS):
            reservation_rows.append(
                {
                    "Policy": policy.name,
                    "Action": action,
                    "Reservation fraction": policy.x[k],
                    "Reserved nominal capacity": policy.x[k] * CENTRAL_CAPACITY[k],
                }
            )

        train_residuals, train_costs = [], []
        for d, prob in zip(D, probabilities):
            _, residual, _, navigability, total = evaluate_fixed_policy(
                policy.x, float(d), CENTRAL_CAPACITY, penalty_level
            )
            train_residuals.append(residual)
            train_costs.append(total)
        training_rows.append(
            {
                "Policy": policy.name,
                "First-stage index": first_cost,
                "Calibration expected total": float(probabilities @ np.asarray(train_costs)),
                "Calibration mean residual": float(probabilities @ np.asarray(train_residuals)),
                "Calibration worst residual": float(np.max(train_residuals)),
                "Solver objective": policy.solver_objective,
            }
        )

        for capacity_name, capacity in [("Central", CENTRAL_CAPACITY), ("Lower", LOWER_CAPACITY)]:
            for _, state in validation.iterrows():
                d = float(state["gross_shortfall_mb_d"])
                activation, residual, coverage, navigability, total = evaluate_fixed_policy(
                    policy.x, d, capacity, penalty_level
                )
                oracle = solve_oracle(d, capacity, penalty_level)
                row = {
                    "Policy": policy.name,
                    "Capacity condition": capacity_name,
                    "State": state["state"],
                    "Temporal resolution": state["temporal_resolution"],
                    "Observed flow": float(state["flow_mb_d"]),
                    "Gross shortfall": d,
                    "Coverage": coverage,
                    "Residual": residual,
                    "Navigability": navigability,
                    "Total index": total,
                    "Oracle index": oracle,
                    "Regret": total - oracle,
                }
                for k, action in enumerate(ACTIONS):
                    row[f"Activation - {action}"] = activation[k]
                validation_rows.append(row)

    return historical, validation, pd.DataFrame(reservation_rows), pd.DataFrame(training_rows), pd.DataFrame(validation_rows)


def summarize_validation(validation_results):
    return (
        validation_results.groupby(["Policy", "Capacity condition"], as_index=False)
        .agg(
            Mean_residual=("Residual", "mean"),
            Worst_residual=("Residual", "max"),
            Mean_navigability=("Navigability", "mean"),
            Worst_navigability=("Navigability", "min"),
            Mean_regret=("Regret", "mean"),
            Maximum_regret=("Regret", "max"),
        )
    )


def run_sensitivities():
    weighting_rows = []
    for weighting in ["duration", "equal"]:
        _, _, reservations, _, validation = temporal_experiment(weighting=weighting)
        summary = summarize_validation(validation)
        central = summary[summary["Capacity condition"] == "Central"]
        for _, row in central.iterrows():
            x = reservations[reservations["Policy"] == row["Policy"]].sort_values("Action")
            weighting_rows.append(
                {
                    "Weighting": weighting,
                    "Policy": row["Policy"],
                    "Worst residual": row["Worst_residual"],
                    "Worst navigability": row["Worst_navigability"],
                    "Maximum regret": row["Maximum_regret"],
                    **{
                        f"x_{a}": float(
                            reservations[(reservations["Policy"] == row["Policy"]) & (reservations["Action"] == a)][
                                "Reservation fraction"
                            ].iloc[0]
                        )
                        for a in ACTIONS
                    },
                }
            )

    historical = pd.read_csv(DATA / "historical_periods_2020_2025.csv")
    q25 = historical[historical["period"].str.contains("Q25")]
    annual_2025 = float(np.average(q25["flow_mb_d"], weights=q25["duration_months"]))
    baseline_rows = []
    for label, baseline in [("1H25", 20.9), ("4Q25", 20.7), ("2025 days-weighted", annual_2025)]:
        _, _, reservations, _, validation = temporal_experiment(baseline=baseline)
        summary = summarize_validation(validation)
        central = summary[summary["Capacity condition"] == "Central"]
        for _, row in central.iterrows():
            baseline_rows.append(
                {
                    "Baseline": label,
                    "Baseline flow": baseline,
                    "Policy": row["Policy"],
                    "Worst residual": row["Worst_residual"],
                    "Worst navigability": row["Worst_navigability"],
                    "Maximum regret": row["Maximum_regret"],
                    **{
                        f"x_{a}": float(
                            reservations[(reservations["Policy"] == row["Policy"]) & (reservations["Action"] == a)][
                                "Reservation fraction"
                            ].iloc[0]
                        )
                        for a in ACTIONS
                    },
                }
            )

    penalty_rows = []
    for penalty in [15.0, 25.0, 60.0]:
        _, _, reservations, _, validation = temporal_experiment(penalty_level=penalty)
        summary = summarize_validation(validation)
        central = summary[summary["Capacity condition"] == "Central"]
        for _, row in central.iterrows():
            penalty_rows.append(
                {
                    "Residual penalty": penalty,
                    "Policy": row["Policy"],
                    "Worst residual": row["Worst_residual"],
                    "Worst navigability": row["Worst_navigability"],
                    **{
                        f"x_{a}": float(
                            reservations[(reservations["Policy"] == row["Policy"]) & (reservations["Action"] == a)][
                                "Reservation fraction"
                            ].iloc[0]
                        )
                        for a in ACTIONS
                    },
                }
            )

    pd.DataFrame(weighting_rows).to_csv(OUT / "temporal_weighting_sensitivity.csv", index=False)
    pd.DataFrame(baseline_rows).to_csv(OUT / "temporal_baseline_sensitivity.csv", index=False)
    pd.DataFrame(penalty_rows).to_csv(OUT / "temporal_penalty_sensitivity.csv", index=False)


def create_figures(historical, validation_results, reservations):
    fig, ax = plt.subplots(figsize=(7.4, 4.5))
    ax.plot(historical["period"], historical["flow_mb_d"], marker="o", label="Observed flow")
    ax.axhline(BASELINE_MAIN, linestyle="--", label="4Q25 baseline")
    ax.set_ylabel("Oil flow through Hormuz (mb/d)")
    ax.set_xlabel("")
    ax.tick_params(axis="x", rotation=30)
    ax.set_title("Pre-2026 calibration observations")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIG / "historical_hormuz_flow_2020_2025.png", dpi=300)
    plt.close(fig)

    central = validation_results[validation_results["Capacity condition"] == "Central"]
    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    for policy, group in central.groupby("Policy"):
        ax.plot(group["State"], group["Navigability"], marker="o", label=policy)
    ax.set_ylabel("Preparedness coverage ratio")
    ax.set_xlabel("")
    ax.set_ylim(0.0, 0.42)
    ax.tick_params(axis="x", rotation=20)
    ax.set_title("Frozen pre-2026 portfolios evaluated on 2026 states")
    ax.legend()
    fig.tight_layout()
    fig.savefig(FIG / "temporal_validation_navigability.png", dpi=300)
    plt.close(fig)

    pivot = reservations.pivot(index="Policy", columns="Action", values="Reservation fraction")
    fig, ax = plt.subplots(figsize=(7.4, 4.5))
    pivot.plot(kind="bar", ax=ax)
    ax.set_ylabel("Reservation fraction")
    ax.set_xlabel("")
    ax.set_ylim(0.0, 1.0)
    ax.set_title("Preparedness portfolios calibrated on 2020-2025 observations")
    fig.tight_layout()
    fig.savefig(FIG / "temporal_calibration_portfolios.png", dpi=300)
    plt.close(fig)


def write_environment(runtime_seconds):
    try:
        from scipy.optimize._highspy import _core as highs_core

        highs_version = (
            f"{highs_core.HIGHS_VERSION_MAJOR}."
            f"{highs_core.HIGHS_VERSION_MINOR}."
            f"{highs_core.HIGHS_VERSION_PATCH}"
        )
    except Exception:
        highs_version = "not exposed"

    environment = {
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "matplotlib": matplotlib.__version__,
        "highs": highs_version,
        "platform": platform.platform(),
        "runtime_seconds": runtime_seconds,
    }
    (OUT / "temporal_computational_environment.json").write_text(json.dumps(environment, indent=2))


def main():
    start = time.perf_counter()
    historical, validation, reservations, training, validation_results = temporal_experiment()
    summary = summarize_validation(validation_results)

    historical.to_csv(OUT / "historical_calibration_periods.csv", index=False)
    validation.to_csv(OUT / "validation_states_2026.csv", index=False)
    reservations.to_csv(OUT / "temporal_policy_reservations.csv", index=False)
    training.to_csv(OUT / "temporal_training_results.csv", index=False)
    validation_results.to_csv(OUT / "temporal_validation_results.csv", index=False)
    summary.to_csv(OUT / "temporal_validation_summary.csv", index=False)

    run_sensitivities()
    create_figures(historical, validation_results, reservations)

    runtime = time.perf_counter() - start
    write_environment(runtime)

    main_summary = {
        "baseline_mb_d": BASELINE_MAIN,
        "calibration_periods": int(len(historical)),
        "calibration_month_equivalents": int(historical["duration_months"].sum()),
        "validation_states": int(len(validation)),
        "validation_probabilities_assigned": False,
        "runtime_seconds": runtime,
    }
    (OUT / "temporal_validation_metadata.json").write_text(json.dumps(main_summary, indent=2))
    print(json.dumps(main_summary, indent=2))
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
