"""Repeat the exact August 6, 2026 original 280-point CVaR grid using the September R2 model.
The grid and loop order are taken verbatim from expanded_cvar_breakpoints() in the original archive.
The R2 core model data and functions are kept unmodified.
"""
import importlib.util
from pathlib import Path
import sys
import numpy as np
import pandas as pd

SRC = Path(__file__).resolve().parent / 'core_empirical_model.py'
OUT = Path(__file__).resolve().parent.parent / 'outputs' / 'cvar_breakpoint_280_original_grid_R2.csv'
spec = importlib.util.spec_from_file_location('omr_r2_original_grid_verification', SRC)
m = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)

rows=[]; p0=m.PRIORS['Balanced']; C=m.PROFILES['Central-response']; B=1.6
base_pen=m.penalty_base.copy()
for tail_mult in [1,2,4,8,16]:
    pen=base_pen.copy(); pen[-1]*=tail_mult
    rsp,c0,h0=m.solve_sp(B,p0,pen,C); xsp=rsp.x[:m.K]
    for alpha in [0.50,0.70,0.80,0.90,0.95,0.975,0.99]:
        for rw in [0.1,0.5,1,2,5,10,25,50]:
            r,c0,h0=m.solve_cvar(B,p0,pen,C,alpha,rw)
            z=m.unpack('CVaR',r,p0,pen,C,c0,h0)
            diff=float(np.max(np.abs(z.x-xsp)))
            rows.append({'Acute penalty multiplier':tail_mult,'alpha':alpha,'risk_weight':rw,
                         'max_abs_x_difference':diff,'Portfolio differs':diff>1e-6,
                         'Expected total':z.expected_total,'Worst residual':z.u.max(),
                         **{f'x_{m.ACTIONS[k]}':z.x[k] for k in range(m.K)}})
df=pd.DataFrame(rows)
df.to_csv(OUT,index=False)
print('R2 requirements:',m.D.tolist())
print('R2 total:',len(df),'distinct portfolios:',int(df['Portfolio differs'].sum()),'maximum difference:',df['max_abs_x_difference'].max())
print('R2 unique portfolios:',df[[f'x_{a}' for a in m.ACTIONS]].drop_duplicates().to_string(index=False))
print('R2 output:',OUT)
