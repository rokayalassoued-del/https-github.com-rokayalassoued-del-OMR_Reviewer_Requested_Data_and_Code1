"""Independent statewise post-optimization evaluation (Reviewer 3 Major Comment 1).
Runs the three original phase-priority cases and records the nominal and
path-consistent robust indicators from independently optimized recourse.
"""
import sys
from pathlib import Path
import pandas as pd
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import duration_aware_hormuz_optimization as m
out=Path(__file__).resolve().parent.parent/'outputs'
durations=m.DURATION_PROFILES['Central']; readiness=m.READINESS_PROFILES['Central']; endurance=30.0
rows=[]; states=[]
for name,p in m.PHASE_PRIORITY_PROFILES.items():
    solved=m.solve_path_consistent_robust(durations,p,readiness,endurance)
    x=solved['x']; nominal=m.evaluate_fixed_nominal(x,durations,p,readiness,endurance)
    robust=m.evaluate_fixed_path_robust(x,durations,p,readiness,endurance)
    assert abs(robust['solver_objective']-solved['solver_objective']) < 1e-5
    rows.append({'Priority profile':name,'x_stock':x[0],'x_bypass':x[1],'x_demand':x[2],
      'Nominal cumulative coverage':nominal['cumulative_preparedness_coverage'],
      'Worst-case cumulative coverage':robust['cumulative_preparedness_coverage'],
      'Worst-phase coverage':robust['worst_phase_preparedness_coverage'],
      'Peak residual (mb/d)':robust['peak_daily_residual_mbd'],
      'Robust objective':solved['solver_objective']})
    for st in robust['scenario_metrics']:
        for t in range(m.T):
            states.append({'Priority profile':name,'Stress state':st['stress_state_id'],
              'Phase':t+1,'Capacity stock':st['capacity'][0],
              'Capacity bypass':st['capacity'][1], 'Capacity demand':st['capacity'][2],
              'Residual (mb/d)':st['residual'][t],
              'Phase coverage':st['phase_preparedness_coverage'][t],
              'Operating loss':st['operating_objective']})
pd.DataFrame(rows).to_csv(out/'reviewer3_priority_nominal_vs_robust.csv',index=False)
pd.DataFrame(states).to_csv(out/'reviewer3_robust_statewise_phase_recourses.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False))
print('Stress-state phase rows:',len(states))
